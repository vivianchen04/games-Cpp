#include <ctime>
#include <random>
#include "FileData.h"
#include "Game.h"
#include "AI_Player.h"

std::mt19937 BattleShip::AI_Player::generator(5);

int main(int argc, char** argv) {

  std::string file_name(argv[1]);
  BattleShip::FileData configure(file_name);

  if (argc == 2) {
    long seed = time(nullptr);
    std::mt19937 rand_generator(seed);
    BattleShip::AI_Player::generator = rand_generator;
  } else {
    long seed = std::stol(argv[2]);
    std::mt19937 rand_generator(seed);
    BattleShip::AI_Player::generator = rand_generator;
  }

  BattleShip::Game(configure);

  return 0;
}
