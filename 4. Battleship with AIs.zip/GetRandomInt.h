//
// Created by Lingxiao Ren on 5/20/22.
//

#ifndef BATTLESHIP_GETRANDOMINT_H
#define BATTLESHIP_GETRANDOMINT_H

int Get_Random_Int(int min, int max, std::mt19937& generator);

#endif //BATTLESHIP_GETRANDOMINT_H
