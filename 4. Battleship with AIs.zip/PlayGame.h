//
// Created by Lingxiao Ren on 5/11/22.
//

#ifndef BATTLESHIP_PLAYGAME_H
#define BATTLESHIP_PLAYGAME_H

#include "Human_Player.h"
#include <memory>

namespace BattleShip {

  bool Has_Finished(std::unique_ptr<Player>& player1_ptr, std::unique_ptr<Player>& player2_ptr,
                    const std::vector<std::pair<char, int>>& ship_vec);

  void Play_Game(std::unique_ptr<Player>& player1_ptr, std::unique_ptr<Player>& player2_ptr,
                 const BattleShip::FileData& config);

  bool Has_P1_Win(const Board& p2_placement_board, const std::vector<std::pair<char, int>>& ship_vec);

  bool Has_P2_Win(const Board& p1_placement_board, const std::vector<std::pair<char, int>>& ship_vec);

  void P1_Move(std::unique_ptr<Player>& p1_ptr, std::unique_ptr<Player>& p2_ptr,
               std::vector<std::pair<int, int>>& p1_all_vec, std::vector<std::pair<int, int>>& vec_needfire);

  void P2_Move(std::unique_ptr<Player>& p2_ptr, std::unique_ptr<Player>& p1_ptr,
               std::vector<std::pair<int, int>>& p2_all_vec, std::vector<std::pair<int, int>>& vec_needfire);

}

#endif //BATTLESHIP_PLAYGAME_H
