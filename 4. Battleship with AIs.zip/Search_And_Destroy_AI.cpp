//
// Created by Lingxiao Ren on 5/20/22.
//

#include "Search_And_Destroy_AI.h"
#include <algorithm>

namespace BattleShip {
  Search_And_Destroy_AI::Search_And_Destroy_AI(Board& place_board, Board& fire_board, int num) : RandomAI(place_board,
                                                                                                          fire_board,
                                                                                                          num) {}

  std::pair<int, int>
  Search_And_Destroy_AI::Fire(std::unique_ptr<BattleShip::Player>& opponent_ptr, std::vector<std::pair<int, int>>& vec,
                              std::vector<std::pair<int, int>>& vec_needfire) const {
    std::pair<int, int> fire_coord;
    if (vec_needfire.size() == 0) {
      fire_coord = RandomAI::Fire(opponent_ptr, vec, vec_needfire);
      if (opponent_ptr->Does_Hit(fire_coord)) {
        std::pair<int, int> left_need_fire = std::make_pair(fire_coord.first, fire_coord.second-1);
        if (m_fire_board.Is_Pair_Inside_Board(left_need_fire) && m_fire_board.Can_Fire(left_need_fire)) {
          vec_needfire.push_back(left_need_fire);
        }
        std::pair<int, int> up_need_fire = std::make_pair(fire_coord.first-1, fire_coord.second);
        if (m_fire_board.Is_Pair_Inside_Board(up_need_fire) && m_fire_board.Can_Fire(up_need_fire)) {
          vec_needfire.push_back(up_need_fire);
        }
        std::pair<int, int> right_need_fire = std::make_pair(fire_coord.first, fire_coord.second+1);
        if (m_fire_board.Is_Pair_Inside_Board(right_need_fire) && m_fire_board.Can_Fire(right_need_fire)) {
          vec_needfire.push_back(right_need_fire);
        }
        std::pair<int, int> down_need_fire = std::make_pair(fire_coord.first+1, fire_coord.second);
        if (m_fire_board.Is_Pair_Inside_Board(down_need_fire) && m_fire_board.Can_Fire(down_need_fire)) {
          vec_needfire.push_back(down_need_fire);
        }
      }
      return fire_coord;
    } else {
      fire_coord = vec_needfire.at(0);


      if (opponent_ptr->Does_Hit(fire_coord)) {
        std::pair<int, int> left_need_fire = std::make_pair(fire_coord.first, fire_coord.second-1);
        if (m_fire_board.Is_Pair_Inside_Board(left_need_fire) && m_fire_board.Can_Fire(left_need_fire)) {
          if (vec.end() != std::find(vec.begin(), vec.end(), left_need_fire) &&
              vec_needfire.end() == std::find(vec_needfire.begin(), vec_needfire.end(), left_need_fire)) {
            vec_needfire.push_back(left_need_fire);
          }
        }
        std::pair<int, int> up_need_fire = std::make_pair(fire_coord.first-1, fire_coord.second);
        if (m_fire_board.Is_Pair_Inside_Board(up_need_fire) && m_fire_board.Can_Fire(up_need_fire)) {
          if (vec.end() != std::find(vec.begin(), vec.end(), up_need_fire) &&
              vec_needfire.end() == std::find(vec_needfire.begin(), vec_needfire.end(), up_need_fire)) {
            vec_needfire.push_back(up_need_fire);
          }
        }
        std::pair<int, int> right_need_fire = std::make_pair(fire_coord.first, fire_coord.second+1);
        if (m_fire_board.Is_Pair_Inside_Board(right_need_fire) && m_fire_board.Can_Fire(right_need_fire)) {
          if (vec.end() != std::find(vec.begin(), vec.end(), right_need_fire) &&
              vec_needfire.end() == std::find(vec_needfire.begin(), vec_needfire.end(), right_need_fire)) {
            vec_needfire.push_back(right_need_fire);
          }
        }
        std::pair<int, int> down_need_fire = std::make_pair(fire_coord.first+1, fire_coord.second);
        if (m_fire_board.Is_Pair_Inside_Board(down_need_fire) && m_fire_board.Can_Fire(down_need_fire)) {
          if (vec.end() != std::find(vec.begin(), vec.end(), down_need_fire) &&
              vec_needfire.end() == std::find(vec_needfire.begin(), vec_needfire.end(), down_need_fire)) {
            vec_needfire.push_back(down_need_fire);
          }
        }
      }
      vec_needfire.erase(vec_needfire.begin());
      auto position = std::find(vec.begin(), vec.end(), fire_coord);
      if (position != vec.end()) {
        vec.erase(position);
      }
      return fire_coord;
    }
  }

} // BattleShip