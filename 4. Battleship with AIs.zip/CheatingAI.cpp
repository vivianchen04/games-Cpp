//
// Created by Lingxiao Ren on 5/20/22.
//

#include "CheatingAI.h"

namespace BattleShip {

  CheatingAI::CheatingAI(Board& placementBoard, Board& fireBoard, int AI_number) : AI_Player(placementBoard, fireBoard,
                                                                                             AI_number) {}

  std::pair<int, int>
  CheatingAI::Fire(std::unique_ptr<BattleShip::Player>& opponent_ptr, std::vector<std::pair<int, int>>& vec,
                   std::vector<std::pair<int, int>>& vec_needfire) const {

    const Board& oppo_place_board = opponent_ptr->Get_Player_Placement_Board();
    char** copy_board = oppo_place_board.Get_Board();
    std::pair<int, int> fire_coord;

    std::vector<std::pair<int, int>> cheating_fire_list;
    for (int i = 0; i < oppo_place_board.Get_Num_Row(); ++i) {
      for (int j = 0; j < oppo_place_board.Get_Num_Col(); ++j) {
        if (copy_board[i][j] != '*' && copy_board[i][j] != 'X' && copy_board[i][j] != 'O') {
          fire_coord = std::make_pair(i, j);
          return fire_coord;
        }
      }
    }
    return fire_coord;
  }

  bool CheatingAI::Does_Hit(std::pair<int, int> coordinate) const {
    return m_placement_board.Does_Hit(coordinate);
  }

  void CheatingAI::Hit_Target_Place(std::pair<int, int> coordinate) {
    m_placement_board.Hit(coordinate);
  }

  void CheatingAI::Hit_Target_Fire(std::pair<int, int> coordinate) {
    m_fire_board.Hit(coordinate);
  }

  void CheatingAI::Not_Hit_Place(std::pair<int, int> coordinate) {
    m_placement_board.Not_Hit(coordinate);
  }

  void CheatingAI::Not_Hit_Fire(std::pair<int, int> coordinate) {
    m_fire_board.Not_Hit(coordinate);
  }

  char CheatingAI::Hit_Name(std::pair<int, int> coordinate) {
    return m_placement_board.Hit_Name(coordinate);
  }

  bool CheatingAI::Is_Destroyed(char hit_name) {
    return m_placement_board.Is_Destroyed(hit_name);
  }


} // BattleShip