//
// Created by Lingxiao Ren on 5/9/22.
//

#ifndef BATTLESHIP_GAME_H
#define BATTLESHIP_GAME_H

#include "FileData.h"
#include "Board.h"

#include "PlayGame.h"

#include <memory>
#include <sstream>

namespace BattleShip {

  void Game(const FileData& config);
  void Initialize_Player(std::unique_ptr<Player>& player_ptr, const BattleShip::FileData& config);
} // BattleShip


#endif //BATTLESHIP_GAME_H
