//
// Created by Lingxiao Ren on 5/19/22.
//

#ifndef BATTLESHIP_PLAYER_H
#define BATTLESHIP_PLAYER_H

#include "Board.h"
#include "InputValidation.h"
#include <utility>
#include <memory>

namespace BattleShip {

  class Player {
    public:
      // constructor
      Player(Board& placement_board, Board& fire_board);

      // destructor
      virtual ~Player() = default;

      // getter
      virtual std::string Get_Player_Name() const = 0;
      virtual const Board& Get_Player_Placement_Board() const = 0;
      virtual const Board& Get_Player_File_Board() const = 0;

      // print functions
      void Print_Placement_Board() const;
      void Print_Fire_Board() const;

      // place ship function
      virtual void Place_Ships(const std::vector<std::pair<char, int>>& ship_vec) = 0;
      virtual std::string Prompt_HV(char ship_name) const = 0;
      virtual std::string Prompt_Pair(char ship_name, int length) const = 0;

      // fire function
      virtual std::string Prompt_Fire() const = 0;
      virtual std::pair<int, int>
      Fire(std::unique_ptr<BattleShip::Player>& opponent_ptr, std::vector<std::pair<int, int>>& vec,
           std::vector<std::pair<int, int>>& vec_needfire) const = 0;
      virtual bool Does_Hit(std::pair<int, int> coordinate) const = 0;
      virtual void Hit_Target_Place(std::pair<int, int> coordinate) = 0;
      virtual void Hit_Target_Fire(std::pair<int, int> coordinate) = 0;
      virtual void Not_Hit_Place(std::pair<int, int> coordinate) = 0;
      virtual void Not_Hit_Fire(std::pair<int, int> coordinate) = 0;
      virtual char Hit_Name(std::pair<int, int> coordinate) = 0;
      virtual bool Is_Destroyed(char hit_name) = 0;

    protected:
      Board& m_placement_board;
      Board& m_fire_board;
  };

} // BattleShip

#endif //BATTLESHIP_PLAYER_H
