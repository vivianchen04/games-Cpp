//
// Created by Lingxiao Ren on 5/20/22.
//

#include <random>
#include "GetRandomInt.h"

int Get_Random_Int(int min, int max, std::mt19937& generator) {
  std::uniform_int_distribution<int> dist(min, max);
  int random_num = dist(generator);
  return random_num;
}