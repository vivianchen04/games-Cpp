//
// Created by Lingxiao Ren on 5/20/22.
//

#ifndef BATTLESHIP_SEARCH_AND_DESTROY_AI_H
#define BATTLESHIP_SEARCH_AND_DESTROY_AI_H

#include "RandomAI.h"

namespace BattleShip {

  class Search_And_Destroy_AI : public RandomAI {
    public:
      Search_And_Destroy_AI(Board& place_board, Board& fire_board, int num);
      std::pair<int, int>
      Fire(std::unique_ptr<BattleShip::Player>& opponent_ptr, std::vector<std::pair<int, int>>& vec,
           std::vector<std::pair<int, int>>& vec_needfire) const override;

  };

} // BattleShip

#endif //BATTLESHIP_SEARCH_AND_DESTROY_AI_H
