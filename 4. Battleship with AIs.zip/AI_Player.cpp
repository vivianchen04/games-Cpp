//
// Created by Lingxiao Ren on 5/19/22.
//

#include "AI_Player.h"

namespace BattleShip {

  AI_Player::AI_Player(Board& placementBoard, Board& fireBoard, int AI_number) : Player(placementBoard, fireBoard),
                                                                                 m_AI_number(AI_number) {}

  void AI_Player::Place_Ships(const std::vector<std::pair<char, int>>& ship_vec) {

    for (auto itr = ship_vec.begin(); itr != ship_vec.end(); ++itr) {

      char ship_name = itr->first;
      int length = itr->second;

      while (true) {

        int choice_01 = Get_Random_Int(0, 1, generator);

        if (choice_01 == 0) { // 0 means horizontal

          int random_row = Get_Random_Int(0, m_placement_board.Get_Num_Row() - 1, generator);
          int random_col = Get_Random_Int(0, m_placement_board.Get_Num_Col() - length, generator);
          std::pair<int, int> bow_pair = std::make_pair(random_row, random_col);
          std::pair<int, int> stern_pair = std::make_pair(bow_pair.first, bow_pair.second + length - 1);

          if (m_placement_board.Can_Place_Ship(bow_pair, stern_pair)) {
            m_placement_board.Place_Ship(bow_pair, stern_pair, ship_name);
            break;
          }
        } else { // 1 means vertical

          int random_row = Get_Random_Int(0, m_placement_board.Get_Num_Row() - length, generator);
          int random_col = Get_Random_Int(0, m_placement_board.Get_Num_Col() - 1, generator);
          std::pair<int, int> bow_pair = std::make_pair(random_row, random_col);
          std::pair<int, int> stern_pair = std::make_pair(bow_pair.first + length - 1, bow_pair.second);

          if (m_placement_board.Can_Place_Ship(bow_pair, stern_pair)) {
            m_placement_board.Place_Ship(bow_pair, stern_pair, ship_name);
            break;
          }
        }
      }
      std::cout << Get_Player_Name() << "'s Board" << std::endl;
      m_placement_board.Print_Board();
      std::cout << std::endl;
    }
  }

  std::string AI_Player::Get_Player_Name() const {

    std::string name;
    std::ostringstream nameOSS;

    nameOSS.clear();
    nameOSS << "AI " << m_AI_number;

    name = nameOSS.str();

    return name;
  }

  const Board& AI_Player::Get_Player_Placement_Board() const {
    return m_placement_board;
  }

  const Board& AI_Player::Get_Player_File_Board() const {
    return m_fire_board;
  }

  std::string AI_Player::Prompt_HV(char ship_name) const {
    return "You should not call this function in an AI player.";
  }

  std::string AI_Player::Prompt_Pair(char ship_name, int length) const {
    return "You should not call this function in an AI player.";
  }

  std::string AI_Player::Prompt_Fire() const {
    return "You should not call this function in an AI player.";
  }

} // BattleShip