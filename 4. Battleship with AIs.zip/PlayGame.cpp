//
// Created by Lingxiao Ren on 5/11/22.
//

#include "PlayGame.h"

bool BattleShip::Has_P1_Win(const BattleShip::Board& p2_placement_board, const std::vector<std::pair<char, int>>& ship_vec) {
  for (auto itr = ship_vec.begin(); itr != ship_vec.end(); ++itr) {
    if (p2_placement_board.Is_Ship_Alive(itr->first)) {
      return false;
    }
  }
  return true;
}

bool BattleShip::Has_P2_Win(const Board& p1_placement_board, const std::vector<std::pair<char, int>>& ship_vec) {
  for (auto itr = ship_vec.begin(); itr != ship_vec.end(); ++itr) {
    if (p1_placement_board.Is_Ship_Alive(itr->first)) {
      return false;
    }
  }
  return true;
}

bool BattleShip::Has_Finished(std::unique_ptr<Player>& player1_ptr, std::unique_ptr<Player>& player2_ptr,
                              const std::vector<std::pair<char, int>>& ship_vec) {

  const Board& p1_placement_board = player1_ptr->Get_Player_Placement_Board();
  const Board& p2_placement_board = player2_ptr->Get_Player_Placement_Board();

  return Has_P1_Win(p2_placement_board, ship_vec) || Has_P2_Win(p1_placement_board, ship_vec);
}

void BattleShip::P1_Move(std::unique_ptr<Player>& p1_ptr, std::unique_ptr<Player>& p2_ptr,
                         std::vector<std::pair<int, int>>& p1_all_vec, std::vector<std::pair<int, int>>& vec_needfire) {
  std::pair<int, int> fire_coord = p1_ptr->Fire(p2_ptr, p1_all_vec, vec_needfire);

  if (p2_ptr->Does_Hit(fire_coord)) { // if successful hit

    char hit_name = p2_ptr->Hit_Name(fire_coord);

    p1_ptr->Hit_Target_Fire(fire_coord);
    p2_ptr->Hit_Target_Place(fire_coord);

    std::cout << p1_ptr->Get_Player_Name() << "'s Firing Board" << std::endl;
    p1_ptr->Print_Fire_Board();
    std::cout << std::endl;
    std::cout << std::endl;
    std::cout << p1_ptr->Get_Player_Name() << "'s Placement Board" << std::endl;
    p1_ptr->Print_Placement_Board();

    std::cout << p1_ptr->Get_Player_Name() << " hit " << p2_ptr->Get_Player_Name() << "'s " << hit_name << "!" << std::endl;
    if (p2_ptr->Is_Destroyed(hit_name)) {
      std::cout << p1_ptr->Get_Player_Name() << " destroyed " << p2_ptr->Get_Player_Name() << "'s " << hit_name << "!" << std::endl;
    }
    std::cout << std::endl;
  } else {
    p1_ptr->Not_Hit_Fire(fire_coord);
    p2_ptr->Not_Hit_Place(fire_coord);

    std::cout << p1_ptr->Get_Player_Name() << "'s Firing Board" << std::endl;
    p1_ptr->Print_Fire_Board();
    std::cout << std::endl;
    std::cout << std::endl;
    std::cout << p1_ptr->Get_Player_Name() << "'s Placement Board" << std::endl;
    p1_ptr->Print_Placement_Board();
    std::cout << "Missed." << std::endl;
    std::cout << std::endl;
  }
}

void BattleShip::P2_Move(std::unique_ptr<Player>& p2_ptr, std::unique_ptr<Player>& p1_ptr,
                         std::vector<std::pair<int, int>>& p2_all_vec, std::vector<std::pair<int, int>>& vec_needfire) {
  std::pair<int, int> fire_coord = p2_ptr->Fire(p1_ptr, p2_all_vec, vec_needfire);

  if (p1_ptr->Does_Hit(fire_coord)) { // if successful hit

    char hit_name = p1_ptr->Hit_Name(fire_coord);

    p2_ptr->Hit_Target_Fire(fire_coord);
    p1_ptr->Hit_Target_Place(fire_coord);

    std::cout << p2_ptr->Get_Player_Name() << "'s Firing Board" << std::endl;
    p2_ptr->Print_Fire_Board();
    std::cout << std::endl;
    std::cout << std::endl;
    std::cout << p2_ptr->Get_Player_Name() << "'s Placement Board" << std::endl;
    p2_ptr->Print_Placement_Board();

    std::cout << p2_ptr->Get_Player_Name() << " hit " << p1_ptr->Get_Player_Name() << "'s " << hit_name << "!" << std::endl;
    if (p1_ptr->Is_Destroyed(hit_name)) {
      std::cout << p2_ptr->Get_Player_Name() << " destroyed " << p1_ptr->Get_Player_Name() << "'s " << hit_name << "!" << std::endl;
    }
    std::cout << std::endl;
  } else {
    p2_ptr->Not_Hit_Fire(fire_coord);
    p1_ptr->Not_Hit_Place(fire_coord);

    std::cout << p2_ptr->Get_Player_Name() << "'s Firing Board" << std::endl;
    p2_ptr->Print_Fire_Board();
    std::cout << std::endl;
    std::cout << std::endl;
    std::cout << p2_ptr->Get_Player_Name() << "'s Placement Board" << std::endl;
    p2_ptr->Print_Placement_Board();
    std::cout << "Missed." << std::endl;
    std::cout << std::endl;
  }
}

void BattleShip::Play_Game(std::unique_ptr<Player>& player1_ptr, std::unique_ptr<Player>& player2_ptr,
                           const BattleShip::FileData& config) {

  int cur_player = 1;
  const std::vector<std::pair<char, int>>& ship_vec = config.Get_Ship_Vec();

  std::vector<std::pair<int, int>> all_coord_for_p1;

  for (int i = 0; i < config.Get_Num_Row(); ++i) {
    for (int j = 0; j < config.Get_Num_Col(); ++j) {
      all_coord_for_p1.emplace_back(i, j);
    }
  }

  std::vector<std::pair<int, int>> need_fire_p1;
  std::vector<std::pair<int, int>> need_fire_p2;

  std::vector<std::pair<int, int>> all_coord_for_p2 = all_coord_for_p1;

  // play game
  while(!Has_Finished(player1_ptr, player2_ptr, ship_vec)) {
    if ((cur_player % 2) == 1) {
      // player 1 move
      P1_Move(player1_ptr, player2_ptr, all_coord_for_p1, need_fire_p1);
      cur_player++;
    } else {
      // player 2 move
      P2_Move(player2_ptr, player1_ptr, all_coord_for_p2, need_fire_p2);
      cur_player++;
    }
  }

  // announcing result
  if ((cur_player % 2) == 1) {
    // player 2 win
    std::cout << player2_ptr->Get_Player_Name() << " won the game!" << std::endl;
  } else {
    // player 1 win
    std::cout << player1_ptr->Get_Player_Name() << " won the game!" << std::endl;
  }

}
