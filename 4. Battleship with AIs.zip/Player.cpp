//
// Created by Lingxiao Ren on 5/19/22.
//

#include "Player.h"

namespace BattleShip {

  Player::Player(Board& placement_board, Board& fire_board) : m_placement_board(placement_board), m_fire_board(fire_board) {}

  void Player::Print_Placement_Board() const {
    m_placement_board.Print_Board();
  }

  void Player::Print_Fire_Board() const {
    m_fire_board.Print_Board();
  }

} // BattleShip