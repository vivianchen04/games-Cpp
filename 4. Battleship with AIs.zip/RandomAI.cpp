//
// Created by Lingxiao Ren on 5/20/22.
//

#include "RandomAI.h"

namespace BattleShip {

  RandomAI::RandomAI(Board& place_board, Board& fire_board, int AI_num) : AI_Player(place_board, fire_board, AI_num) {}

  std::pair<int, int>
  RandomAI::Fire(std::unique_ptr<BattleShip::Player>& opponent_ptr, std::vector<std::pair<int, int>>& vec,
                 std::vector<std::pair<int, int>>& vec_needfire) const {

    int fire_index = Get_Random_Int(0, vec.size() - 1, generator);
    std::pair<int, int> fire_coord = vec.at(fire_index);
    vec.erase(vec.begin() + fire_index);
    return fire_coord;
  }

  bool RandomAI::Does_Hit(std::pair<int, int> coordinate) const {
    return m_placement_board.Does_Hit(coordinate);
  }

  void RandomAI::Hit_Target_Place(std::pair<int, int> coordinate) {
    m_placement_board.Hit(coordinate);
  }

  void RandomAI::Hit_Target_Fire(std::pair<int, int> coordinate) {
    m_fire_board.Hit(coordinate);
  }

  void RandomAI::Not_Hit_Place(std::pair<int, int> coordinate) {
    m_placement_board.Not_Hit(coordinate);
  }

  void RandomAI::Not_Hit_Fire(std::pair<int, int> coordinate) {
    m_fire_board.Not_Hit(coordinate);
  }

  char RandomAI::Hit_Name(std::pair<int, int> coordinate) {
    return m_placement_board.Hit_Name(coordinate);
  }

  bool RandomAI::Is_Destroyed(char hit_name) {
    return m_placement_board.Is_Destroyed(hit_name);
  }


} // BattleShip