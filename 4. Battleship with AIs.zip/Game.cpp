//
// Created by Lingxiao Ren on 5/9/22.
//

#include "Game.h"
#include "Human_Player.h"
#include "CheatingAI.h"
#include "Search_And_Destroy_AI.h"

void BattleShip::Initialize_Player(std::unique_ptr<Player>& player_ptr, const BattleShip::FileData& config) {
  const std::vector<std::pair<char, int>>& ship_vec = config.Get_Ship_Vec();
  player_ptr->Place_Ships(ship_vec);
}

void BattleShip::Game(const FileData& config) {

  int choice;
  std::string choice_line;

  std::cout << "What type of game do you want to play?" << std::endl;
  std::cout << "1. Human vs Human" << std::endl;
  std::cout << "2. Human vs AI" << std::endl;
  std::cout << "3. AI vs AI" << std::endl;
  std::cout << "Your choice: ";

  std::getline(std::cin, choice_line);
  std::stringstream line2parse(choice_line);
  line2parse >> choice;

  BattleShip::Board player1_placement_board(config);
  BattleShip::Board player1_fire_board(config);

  BattleShip::Board player2_placement_board(config);
  BattleShip::Board player2_fire_board(config);

  std::unique_ptr<Player> player1_ptr;
  std::unique_ptr<Player> player2_ptr;

  if (choice == 1) {

    // play game with two players
    player1_ptr = std::make_unique<Human_Player>(player1_placement_board, player1_fire_board, 1);
    Initialize_Player(player1_ptr, config);

    player2_ptr = std::make_unique<Human_Player>(player2_placement_board, player2_fire_board, 2);
    Initialize_Player(player2_ptr, config);
  }

  if (choice == 2) {

    // play game with an AI and a player

    std::string single_AI_choice_line;
    int single_AI_choice;

    std::cout << "What AI do you want?" << std::endl;
    std::cout << "1. Cheating AI" << std::endl;
    std::cout << "2. Random AI" << std::endl;
    std::cout << "3. Hunt Destroy AI" << std::endl;
    std::cout << "Your choice: ";

    std::getline(std::cin, single_AI_choice_line);
    std::stringstream single_AI_line2parse(single_AI_choice_line);
    single_AI_line2parse >> single_AI_choice;

    player1_ptr = std::make_unique<Human_Player>(player1_placement_board, player1_fire_board, 1);
    Initialize_Player(player1_ptr, config);

    if (single_AI_choice == 1) {
      player2_ptr = std::make_unique<CheatingAI>(player2_placement_board, player2_fire_board, 1);
    }
    if (single_AI_choice == 2) {
      player2_ptr = std::make_unique<RandomAI>(player2_placement_board, player2_fire_board, 1);
    }
    if (single_AI_choice == 3) {
      player2_ptr = std::make_unique<Search_And_Destroy_AI>(player2_placement_board, player2_fire_board, 1);
    }

    Initialize_Player(player2_ptr, config);
  }

  if (choice == 3) {  // play game with double AI

    std::string double_AI_choice1_line;
    int double_AI_choice1;

    std::cout << "What AI do you want?" << std::endl;
    std::cout << "1. Cheating AI" << std::endl;
    std::cout << "2. Random AI" << std::endl;
    std::cout << "3. Hunt Destroy AI" << std::endl;
    std::cout << "Your choice: ";

    std::getline(std::cin, double_AI_choice1_line);
    std::stringstream double_AI1_line2parse(double_AI_choice1_line);
    double_AI1_line2parse >> double_AI_choice1;

    if (double_AI_choice1 == 1) {
      player1_ptr = std::make_unique<CheatingAI>(player1_placement_board, player1_fire_board, 1);
    }
    if (double_AI_choice1 == 2) {
      player1_ptr = std::make_unique<RandomAI>(player1_placement_board, player1_fire_board, 1);
    }
    if (double_AI_choice1 == 3) {
      player1_ptr = std::make_unique<Search_And_Destroy_AI>(player1_placement_board, player1_fire_board, 1);
    }
    Initialize_Player(player1_ptr, config);

    std::string double_AI_choice2_line;
    int double_AI_choice2;

    std::cout << "What AI do you want?" << std::endl;
    std::cout << "1. Cheating AI" << std::endl;
    std::cout << "2. Random AI" << std::endl;
    std::cout << "3. Hunt Destroy AI" << std::endl;
    std::cout << "Your choice: ";

    std::getline(std::cin, double_AI_choice2_line);
    std::stringstream double_AI2_line2parse(double_AI_choice2_line);
    double_AI2_line2parse >> double_AI_choice2;

    if (double_AI_choice2 == 1) {
      player2_ptr = std::make_unique<CheatingAI>(player2_placement_board, player2_fire_board, 2);
    }
    if (double_AI_choice2 == 2) {
      player2_ptr = std::make_unique<RandomAI>(player2_placement_board, player2_fire_board, 2);
    }
    if (double_AI_choice2 == 3) {
      player2_ptr = std::make_unique<Search_And_Destroy_AI>(player2_placement_board, player2_fire_board, 2);
    }
    Initialize_Player(player2_ptr, config);
  }
  Play_Game(player1_ptr, player2_ptr, config);
  player1_ptr.reset();
  player2_ptr.reset();
}




