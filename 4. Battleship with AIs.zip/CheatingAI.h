//
// Created by Lingxiao Ren on 5/20/22.
//

#ifndef BATTLESHIP_CHEATINGAI_H
#define BATTLESHIP_CHEATINGAI_H

#include "AI_Player.h"

namespace BattleShip {

  class CheatingAI : public AI_Player {
    public:
      // constructor
      CheatingAI(Board& placementBoard, Board& fireBoard, int AI_number);

      // getter
      // std::string Get_Player_Name() const override;
      // const Board& Get_Player_Placement_Board() const override;
      // const Board& Get_Player_File_Board() const override;

      // print function
      // void Print_Placement_Board() const;
      // void Print_Fire_Board() const;

      // place ships function
      // void Place_Ships(const std::vector<std::pair<char, int>>& ship_vec) override;
      // std::string Prompt_HV(char ship_name) const override;
      // std::string Prompt_Pair(char ship_name, int length) const override;


      // fire functions
      // std::string Prompt_Fire() const override;
      std::pair<int, int>
      Fire(std::unique_ptr<BattleShip::Player>& opponent_ptr, std::vector<std::pair<int, int>>& vec,
           std::vector<std::pair<int, int>>& vec_needfire) const override;
      bool Does_Hit(std::pair<int, int> coordinate) const override;
      void Hit_Target_Place(std::pair<int, int> coordinate) override;
      void Hit_Target_Fire(std::pair<int, int> coordinate) override;
      void Not_Hit_Place(std::pair<int, int> coordinate) override;
      void Not_Hit_Fire(std::pair<int, int> coordinate) override;
      char Hit_Name(std::pair<int, int> coordinate) override;
      bool Is_Destroyed(char hit_name) override;

      // generator
      // static std::mt19937& generator

    // protected:

      // int m_AI_number;
      // Board& m_placement_board;
      // Board& m_fire_board;
  };

} // BattleShip

#endif //BATTLESHIP_CHEATINGAI_H
