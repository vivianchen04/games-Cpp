#ifndef ECS_36B_HOMEWORK_VECTORTESTING_H
#define ECS_36B_HOMEWORK_VECTORTESTING_H
#include "gtest/gtest.h"
#include "Vector.h"

 class VectorTesting : public ::testing::Test{
  public:
   VectorTesting() = default;
  protected:
  //std::vector<Matrix::Vector> _2, _3, _4;

};


#endif //ECS_36B_HOMEWORK_VECTORTESTING_H
