#include "VectorIterator.h"
#include "ConstColumnIterator.h"

Matrix::VectorIterator::VectorIterator(BaseVector* vector, int pos) : vector(vector), pos(pos) {

}

Matrix::VectorIterator::operator ConstVectorIterator() const {
    return ConstVectorIterator(vector, pos);
}

Matrix::VectorIterator::value_type& Matrix::VectorIterator::operator*() {
    return vector->at(pos);
}

const Matrix::VectorIterator::value_type& Matrix::VectorIterator::operator*() const {
    try {
        return vector->at(pos);
    } catch (std::out_of_range& error){
        throw std::logic_error("Cannot dereference an iterator that is out of bounds");
    }
}

const Matrix::VectorIterator::value_type& Matrix::VectorIterator::operator[](int offset) const {
    return vector->at(pos + offset);
}

Matrix::VectorIterator::value_type& Matrix::VectorIterator::operator[](int offset) {
    return vector->at(pos + offset);
}

Matrix::VectorIterator& Matrix::VectorIterator::operator++() {
    pos++;
    return *this;
}

const Matrix::VectorIterator Matrix::VectorIterator::operator++(int) {
    VectorIterator moveElement(*this);
    ++(*this);
    return moveElement;
}

Matrix::VectorIterator& Matrix::VectorIterator::operator--() {
    pos--;
    return *this;
}

const Matrix::VectorIterator Matrix::VectorIterator::operator--(int) {
    VectorIterator moveElement(*this);
    --(*this);
    return moveElement;
}

Matrix::VectorIterator& Matrix::VectorIterator::operator+=(int amount) {
    pos += amount;
    return *this;
}

Matrix::VectorIterator Matrix::VectorIterator::operator+(int amount) const {
    VectorIterator moveElement(*this);
    moveElement.operator+=(amount);
    return moveElement;
}

Matrix::VectorIterator& Matrix::VectorIterator::operator-=(int amount) {
    pos -= amount;
    return *this;
}

Matrix::VectorIterator Matrix::VectorIterator::operator-(int amount) const {
    VectorIterator moveElement(*this);
    moveElement.operator-=(amount);
    return moveElement;
}

Matrix::VectorIterator::difference_type Matrix::VectorIterator::operator-(const VectorIterator& rhs) {
    return pos - rhs.pos;
}

Matrix::VectorIterator::operator bool() const {
    return pos >= 0 and pos < vector->size();
}

bool Matrix::VectorIterator::operator==(const VectorIterator& rhs) const {
    if (static_cast<bool>(*this) and rhs) {
        if (vector == rhs.vector) {
            return pos == rhs.pos;
        } else {
            return false;
        }
    } else if (!*this and !rhs) {
        return vector == rhs.vector;
    } else {
        return false;
    }
}

bool Matrix::VectorIterator::operator!=(const VectorIterator& rhs) const {
    return !(*this == rhs);
}

bool Matrix::VectorIterator::operator<(const VectorIterator& rhs) const {
    return pos < rhs.pos;
}

bool Matrix::VectorIterator::operator<=(const VectorIterator& rhs) const {
    return pos <= rhs.pos;
}

bool Matrix::VectorIterator::operator>(const VectorIterator& rhs) const {
    return pos > rhs.pos;
}

bool Matrix::VectorIterator::operator>=(const VectorIterator& rhs) const {
    return pos >= rhs.pos;
}






