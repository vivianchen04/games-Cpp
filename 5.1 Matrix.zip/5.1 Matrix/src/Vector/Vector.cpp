#include "Vector.h"


Matrix::Vector::Vector(const ConstBaseVector& orig) {
    for (auto value: orig) {
        elements.push_back(value);
    }
}

Matrix::Vector::Vector(int numElements, const BaseVector::value_type& value) {

    for (int i = 0; i < numElements; ++i) {
        elements.push_back(value);
    }
}

Matrix::Vector::Vector(int numElements) {

    for (int i = 0; i < numElements; ++i) {
        elements.push_back(0);
    }
}

Matrix::Vector::Vector(const std::vector<value_type>& values) {
    for (const auto& element: values) {
        elements.push_back(element);
    }
}

Matrix::Vector::Vector() : Vector(1) {

}

int Matrix::Vector::size() const {
    return elements.size();
}

Matrix::BaseVector::value_type& Matrix::Vector::at(int index) {
    if (index < 0 or index >= size()) {
        throw  std::out_of_range("Index given is invalid");
    } else {
        return elements.at(index);
    }
}

const Matrix::BaseVector::value_type& Matrix::Vector::at(int index) const {
    if (index < 0 or index >= size()) {
        throw  std::out_of_range("Index given is invalid");
    } else {
        return elements.at(index);
    }
}

Matrix::BaseVector::value_type& Matrix::Vector::operator[](int index) {
    return at(index);
}

const Matrix::BaseVector::value_type& Matrix::Vector::operator[](int index) const {
    return at(index);
}

Matrix::Vector& Matrix::Vector::operator=(const ConstBaseVector& rhs) {
    auto this_itr = this->begin();
    auto rhs_itr = rhs.begin();

    for (; this_itr != this->end() and rhs_itr != rhs.end(); ++this_itr, ++rhs_itr) {
        *this_itr = *rhs_itr;
    }

    return *this;
}










