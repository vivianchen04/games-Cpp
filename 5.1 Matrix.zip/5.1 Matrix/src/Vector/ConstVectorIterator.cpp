#include "ConstVectorIterator.h"
#include "BaseVector.h"

Matrix::ConstVectorIterator::ConstVectorIterator(const ConstBaseVector* vector, int pos) : vector(vector), pos(pos){

}

const Matrix::ConstVectorIterator::value_type& Matrix::ConstVectorIterator::operator*() const {
    return vector->at(pos);
}

const Matrix::ConstVectorIterator::value_type& Matrix::ConstVectorIterator::operator[](int offset) const {
    return vector->at(pos + offset);
}

Matrix::ConstVectorIterator& Matrix::ConstVectorIterator::operator++() {
    pos++;
    return *this;
}

const Matrix::ConstVectorIterator Matrix::ConstVectorIterator::operator++(int) {
    ConstVectorIterator moveElement(*this);
    ++(*this);
    return moveElement;
}

Matrix::ConstVectorIterator& Matrix::ConstVectorIterator::operator--() {
    pos--;
    return *this;
}

const Matrix::ConstVectorIterator Matrix::ConstVectorIterator::operator--(int) {
    ConstVectorIterator moveElement(*this);
    --(*this);
    return moveElement;
}

Matrix::ConstVectorIterator& Matrix::ConstVectorIterator::operator+=(int amount) {
    pos += amount;
    return *this;
}

Matrix::ConstVectorIterator Matrix::ConstVectorIterator::operator+(int amount) const {
    ConstVectorIterator moveElement(*this);
    moveElement.operator+=(amount);
    return moveElement;
}

Matrix::ConstVectorIterator& Matrix::ConstVectorIterator::operator-=(int amount) {
    pos -= amount;
    return *this;
}

Matrix::ConstVectorIterator Matrix::ConstVectorIterator::operator-(int amount) const {
    ConstVectorIterator moveElement(*this);
    moveElement.operator-=(amount);
    return moveElement;
}

Matrix::ConstVectorIterator::difference_type Matrix::ConstVectorIterator::operator-(const ConstVectorIterator& rhs) {
    return pos - rhs.pos;
}

Matrix::ConstVectorIterator::operator bool() const {
    return pos >= 0 and pos < vector->size();
}

bool Matrix::ConstVectorIterator::operator==(const ConstVectorIterator& rhs) const {
    if (static_cast<bool>(*this) and rhs) {
        if (vector == rhs.vector) {
            return pos == rhs.pos;
        }else{
            return false;
        }
    } else if (!*this and !rhs) {
        return vector == rhs.vector;
    } else {
        return false;
    }
}

bool Matrix::ConstVectorIterator::operator!=(const ConstVectorIterator& rhs) const {
    return !(*this == rhs);
}

bool Matrix::ConstVectorIterator::operator<(const ConstVectorIterator& rhs) const {
    return pos < rhs.pos;
}

bool Matrix::ConstVectorIterator::operator<=(const ConstVectorIterator& rhs) const {
    return pos <= rhs.pos;
}

bool Matrix::ConstVectorIterator::operator>(const ConstVectorIterator& rhs) const {
    return pos > rhs.pos;
}

bool Matrix::ConstVectorIterator::operator>=(const ConstVectorIterator& rhs) const {
    return pos >= rhs.pos;
}
