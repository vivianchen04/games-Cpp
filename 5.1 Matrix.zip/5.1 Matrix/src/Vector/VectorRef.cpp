#include "VectorRef.h"
#include "Matrix.h"

Matrix::VectorRef::VectorRef(BaseVector& orig) : ConstVectorRef(orig) {
}

Matrix::VectorRef::VectorRef(Matrix& matrix, int col) : ConstVectorRef(matrix, col) {

}

int Matrix::VectorRef::size() const {
    return elements.size();
}

Matrix::BaseVector::value_type& Matrix::VectorRef::at(int index) {
    if (index < 0 or index > size()) {
        throw std::out_of_range("Index given is invalid");
    } else {
        return *elements.at(index);
    }
}

const Matrix::BaseVector::value_type& Matrix::VectorRef::at(int index) const {
    if (index < 0 or index > size()) {
        throw std::out_of_range("Index given is invalid");
    } else {
        return *elements.at(index);
    }
}

Matrix::BaseVector::value_type& Matrix::VectorRef::operator[](int index) {
    if (index < 0 or index > size()) {
        throw std::out_of_range("Index given is invalid");
    } else {
        return *elements.at(index);
    }
}

const Matrix::BaseVector::value_type& Matrix::VectorRef::operator[](int index) const {
    if (index < 0 or index > size()) {
        throw std::out_of_range("Index given is invalid");
    } else {
        return *elements.at(index);
    }
}

Matrix::VectorRef& Matrix::VectorRef::operator=(const BaseVector& rhs) {
    for (int i = 0; i < rhs.size(); ++i) {
        *elements.at(i) = rhs.at(i);
    }
    return *this;


//    auto vector_itr = *elements.begin();
//    auto rhs_itr = rhs.begin();
//
//    for (; vector_itr != *elements.end(), rhs_itr != rhs.end(); ++vector_itr, ++rhs_itr) {
//        *vector_itr = *rhs_itr;
//    }
//
//    return *this;


//    auto this_itr = this->begin();
//    auto rhs_itr = rhs.begin();
//
//    for (; this_itr != this->end(), rhs_itr != rhs.end(); ++this_itr, ++rhs_itr) {
//        *this_itr = *rhs_itr;
//    }
//
//    return *this;
}





