#include <functional>
#include <algorithm>
#include "BaseVector.h"
#include "Vector.h"
#include "ConstVectorIterator.h"
#include "VectorIterator.h"
#include "Matrix.h"

Matrix::BaseVector::operator Matrix() const {
    std::vector<Vector> vector;
    Vector copy(*this);
    vector.push_back(copy);
    return Matrix(vector);
}

Matrix::VectorIterator Matrix::BaseVector::begin() {
    return VectorIterator(this, 0);
}

Matrix::VectorIterator Matrix::BaseVector::end() {
    return VectorIterator(this, size());
}

Matrix::ConstVectorIterator Matrix::BaseVector::begin() const {
    return ConstVectorIterator(this, 0);
}

Matrix::ConstVectorIterator Matrix::BaseVector::end() const {
    return ConstVectorIterator(this, size());
}

//// check
Matrix::ConstVectorIterator Matrix::BaseVector::cbegin() const {
    return ConstVectorIterator(this, 0);
}

Matrix::ConstVectorIterator Matrix::BaseVector::cend() const {
    return ConstVectorIterator(this, size());
}

Matrix::BaseVector& Matrix::BaseVector::operator+=(const ConstBaseVector& rhs) {
    auto this_itr = this->begin();
    auto rhs_itr = rhs.begin();

    for(; this_itr != this->end() and rhs_itr != rhs.end(); ++this_itr, ++rhs_itr) {
        *this_itr += *rhs_itr;
    }

    return *this;
}

Matrix::BaseVector& Matrix::BaseVector::operator-=(const ConstBaseVector& rhs) {
    auto self_itr = this->begin();
    auto rhs_itr = rhs.begin();

    for(; self_itr != this->end() and rhs_itr != rhs.end(); ++self_itr, ++rhs_itr) {
        *self_itr -= *rhs_itr;
    }

    return *this;
}

Matrix::BaseVector& Matrix::BaseVector::operator+=(const BaseVector::value_type& rhs) {
    for (auto itr = this->begin(); itr != this->end(); ++itr) {
        *itr += rhs;
    }

    return *this;
}

Matrix::BaseVector& Matrix::BaseVector::operator-=(const BaseVector::value_type& rhs) {
    for (auto itr = this->begin(); itr != this->end(); ++itr) {
        *itr -= rhs;
    }

    return *this;
}

Matrix::BaseVector& Matrix::BaseVector::operator*=(const BaseVector::value_type& rhs) {
    for (auto itr = this->begin(); itr != this->end(); ++itr) {
        *itr *= rhs;
    }

    return *this;
}












