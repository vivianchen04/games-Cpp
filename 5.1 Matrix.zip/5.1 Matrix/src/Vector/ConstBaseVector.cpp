#include <algorithm>
#include "Vector.h"
#include "ConstBaseVector.h"

Matrix::ConstVectorIterator Matrix::ConstBaseVector::begin() const {
    return ConstVectorIterator(this, 0);
}

Matrix::ConstVectorIterator Matrix::ConstBaseVector::end() const {
    return ConstVectorIterator(this, size());
//    return ConstVectorIterator(this, this->size());
}

Matrix::Vector Matrix::ConstBaseVector::operator-() const {
    Vector negated(*this);

//    for (int i = 0; i < negated.size(); ++i) {
//        negated.at(i) = -negated.at(i);
//    }
//
//    for (auto itr = negated.begin(); itr != negated.end(); ++itr) {
//        *itr = -*itr;
//    }

    for (auto& value: negated) {
        value = -value;
    }

    return negated;
}

Matrix::Vector Matrix::ConstBaseVector::operator+(const ConstBaseVector& rhs) {
    Vector sum(*this);

    auto sum_itr = sum.begin();
    auto rhs_itr = rhs.begin();

    for(; sum_itr != sum.end() and rhs_itr != rhs.end(); ++sum_itr, ++rhs_itr) {
        *sum_itr += *rhs_itr;
    }

    return sum;
}

Matrix::Vector Matrix::ConstBaseVector::operator-(const ConstBaseVector& rhs) {
    Vector difference(*this);

    auto difference_itr = difference.begin();
    auto rhs_itr = rhs.begin();

    for(; difference_itr != difference.end() and rhs_itr != rhs.end(); ++difference_itr, ++rhs_itr) {
        *difference_itr -= *rhs_itr;
    }

    return difference;
}

//// check
Matrix::Vector Matrix::ConstBaseVector::operator*(const ConstBaseVector& rhs) const {
    Vector product(*this);

    auto product_itr = product.begin();
    auto rhs_itr = rhs.begin();

    int dotProduct = 0;

    for(; product_itr != product.end() and rhs_itr != rhs.end(); ++product_itr, ++rhs_itr) {
        dotProduct = dotProduct + *product_itr * *rhs_itr;
    }

    return Vector(1, dotProduct);
}

//// check
Matrix::Vector Matrix::ConstBaseVector::operator+(const ConstBaseVector::value_type& rhs) const {
    Vector vectorPlusScalar(*this);

    for (auto& value: vectorPlusScalar) {
        value += rhs;
    }

    return vectorPlusScalar;
}

Matrix::Vector Matrix::ConstBaseVector::operator-(const ConstBaseVector::value_type& rhs) const {
    Vector vectorMinusScalar(*this);

    for (auto& value: vectorMinusScalar) {
        value -= rhs;
    }

    return vectorMinusScalar;
}

Matrix::Vector Matrix::ConstBaseVector::operator*(const ConstBaseVector::value_type& rhs) const {
    Vector vectorTimesScalar(*this);

    for (auto& value: vectorTimesScalar) {
        value *= rhs;
    }

    return vectorTimesScalar;
}

bool Matrix::ConstBaseVector::operator==(const ConstBaseVector& rhs) const {
    for (int i = 0; i < rhs.size(); i++){
        if(this->at(i) != rhs.at(i) ){
            return false;
        }
    }
    return true;
}

bool Matrix::ConstBaseVector::operator!=(const ConstBaseVector& rhs) const {
    return !(*this == rhs);
}

//// check
Matrix::Vector Matrix::operator+(const ConstBaseVector::value_type& lhs, const ConstBaseVector& rhs) {
//    Vector scalarPlusVector(rhs);
//
//    auto sum_itr = scalarPlusVector.begin();
//    auto rhs_itr = rhs.begin();
//
//    for(; sum_itr != scalarPlusVector.end() and rhs_itr != rhs.end(); ++sum_itr, ++rhs_itr) {
//        *sum_itr += lhs;
//    }
//
//    return scalarPlusVector;

    return rhs + lhs;
}

Matrix::Vector Matrix::operator-(const ConstBaseVector::value_type& lhs, const ConstBaseVector& rhs) {
//    Vector scalarMinusVector(rhs);
//
//    auto difference_itr = scalarMinusVector.begin();
//    auto rhs_itr = rhs.begin();
//
//    for(; difference_itr != scalarMinusVector.end() and rhs_itr != rhs.end(); ++difference_itr, ++rhs_itr) {
//        *difference_itr -= lhs;
//    }
//
//    return scalarMinusVector;

    return -rhs + lhs;
}

Matrix::Vector Matrix::operator*(const ConstBaseVector::value_type& lhs, const ConstBaseVector& rhs) {
//    Vector scalarTimesVector;
//
//    auto product_itr = scalarTimesVector.begin();
//    auto rhs_itr = rhs.begin();
//
//    for(; product_itr != scalarTimesVector.end() and rhs_itr != rhs.end(); ++product_itr, ++rhs_itr) {
//        *product_itr *= lhs;
//    }
//
//    return scalarTimesVector;

    return rhs * lhs;
}
