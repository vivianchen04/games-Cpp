#include <algorithm>
#include <functional>
#include "Matrix.h"

Matrix::Matrix::Matrix(int numRows, int numCols, const Matrix::Matrix::element_type& val) : rows(numRows), columns(numCols) {
    for (int i = 0; i < numRows; ++i) {
        matrix.emplace_back(Vector(numCols, val));
    }
}

Matrix::Matrix::Matrix(int numRows, int numCols) {
    rows = numRows;
    columns = numCols;
    for (int i = 0; i < numRows; ++i) {
        matrix.emplace_back(Vector(numCols, 0));
    }
}

Matrix::Matrix::Matrix(const std::vector<std::vector<element_type>>& values) {
    rows = values.size();
    columns = values.at(0).size();
    for (const auto& element: values) {
        matrix.emplace_back(element);
    }
}

Matrix::Matrix::Matrix(const std::vector<Vector>& values) {
    rows = values.size();
    columns = values.at(0).size();
    matrix = values;
}

Matrix::Matrix::Matrix(const std::vector<ConstVectorRef>& values) {
    rows = values.size();
    columns = values.at(0).size();
    for (const auto& element: values) {
        matrix.emplace_back(Vector(element));
    }
}

/////////// TODO: check
Matrix::Matrix::Matrix(const std::vector<VectorRef>& values) {
    rows = values.size();
    columns = values.at(0).size();
    for (const auto& element: values) {
        matrix.emplace_back(Vector(element));
    }
}

Matrix::Matrix Matrix::Matrix::ident(int dim) {
    Matrix identityMatrix = Matrix(dim, dim);
    for (int i = 0; i < dim; ++i) {
        identityMatrix.at(i, i) = 1;
    }
    return identityMatrix;
}

int Matrix::Matrix::getNumRows() const {
    return rows;
}

int Matrix::Matrix::getNumCols() const {
    return columns;
}

int Matrix::Matrix::matrixSize() const {
    return matrix.size();
}

Matrix::Matrix::element_type& Matrix::Matrix::at(int row, int col) {
    return matrix.at(row).at(col);
}

const Matrix::Matrix::element_type& Matrix::Matrix::at(int row, int col) const {
    return matrix.at(row).at(col);
}

/////////// TODO: check
Matrix::VectorRef Matrix::Matrix::rowAt(int row) {
    if (row < 0 or row > rows) {
        throw  std::out_of_range("Row given is invalid");
    } else {
        return VectorRef(matrix.at(row));
    }
}

 Matrix::ConstVectorRef Matrix::Matrix::rowAt(int row) const {
     if (row < 0 or row > rows) {
         throw  std::out_of_range("Row given is invalid");
     } else {
         return ConstVectorRef(matrix.at(row));
     }
}

Matrix::VectorRef Matrix::Matrix::colAt(int col) {
    if (col < 0 or col > columns) {
        throw  std::out_of_range("Column given is invalid");
    } else {
        return VectorRef(*this, col);
    }
}

Matrix::ConstVectorRef Matrix::Matrix::colAt(int col) const {
    if (col < 0 or col > columns) {
        throw  std::out_of_range("Column given is invalid");
    } else {
        return ConstVectorRef(*this, col);
    }
}

////////// TODO: check
Matrix::VectorRef Matrix::Matrix::operator[](int row) {
    return rowAt(row);
}

Matrix::ConstVectorRef Matrix::Matrix::operator[](int row) const {
    return rowAt(row);
}

Matrix::Matrix::const_iterator Matrix::Matrix::begin() const {
    return ConstRowIterator(this, 0);
}

Matrix::Matrix::const_iterator Matrix::Matrix::end() const {
    return ConstRowIterator(this, matrixSize());
}

Matrix::Matrix::iterator Matrix::Matrix::begin() {
    return RowIterator(this, 0);
}

Matrix::Matrix::iterator Matrix::Matrix::end() {
    return RowIterator(this, matrixSize());
}

Matrix::Matrix::const_row_iterator Matrix::Matrix::rowBegin() const {
    return ConstRowIterator(this, 0);
}

Matrix::Matrix::const_row_iterator Matrix::Matrix::rowEnd() const {
    return ConstRowIterator(this, rows);
}

Matrix::Matrix::row_iterator Matrix::Matrix::rowBegin() {
    return RowIterator(this, 0);
}

Matrix::Matrix::row_iterator Matrix::Matrix::rowEnd() {
    return RowIterator(this, rows);
}

Matrix::Matrix::const_column_iterator Matrix::Matrix::colBegin() const {
    return ConstColumnIterator(this, 0);
}

Matrix::Matrix::const_column_iterator Matrix::Matrix::colEnd() const {
    return ConstColumnIterator(this, columns);
}

Matrix::Matrix::column_iterator Matrix::Matrix::colBegin() {
    return ColumnIterator(this, 0);
}

Matrix::Matrix::column_iterator Matrix::Matrix::colEnd() {
    return ColumnIterator(this, columns);
}

Matrix::Matrix Matrix::Matrix::operator-() const{
//    for (auto vector: negated) {  //// check auto or auto&
//        for (auto& value: vector) {
//            value = -value;
//        }
//    }

    Matrix negated(*this);

    for (int i = 0; i < rows; ++i) {
        auto row = negated.rowAt(i);
        row *= -1;
    }

    return negated;
}

Matrix::Matrix& Matrix::Matrix::operator+=(const Matrix& rhs) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < columns; ++j) {
            this->at(i, j) += rhs.at(i, j);
        }
    }

    return *this;
}

Matrix::Matrix Matrix::Matrix::operator+(const Matrix& rhs) {
    Matrix sum(*this);
    sum += rhs;
    return sum;
}

Matrix::Matrix& Matrix::Matrix::operator-=(const Matrix& rhs) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < columns; ++j) {
            this->at(i, j) -= rhs.at(i, j);
        }
    }

    return *this;
}

Matrix::Matrix Matrix::Matrix::operator-(const Matrix& rhs) {
    Matrix difference(*this);
    difference -= rhs;
    return difference;
}

Matrix::Matrix& Matrix::Matrix::operator*=(const Matrix& rhs) {
//    for (int i = 0; i < rows; ++i) {
//        auto this_row = this->rowAt(i);
//        for (int j = 0; j < rhs.columns; ++j) {
//            auto rhs_col = rhs.colAt(j);
//            for (int m = 0; m < columns; ++m) {
//                dotProduct = dotProduct + this_row.at(m)* rhs_col.at(m);
//            }
//            product.at(i, j) = dotProduct;
//            dotProduct = 0;
//        }
//    }

    Matrix product(rows, rhs.columns);
    int dotProduct = 0;

    for (int i = 0; i < rows; ++i) {

        for (int j = 0; j < rhs.columns; ++j) {

            for (int m = 0; m < columns; ++m) {
                dotProduct = dotProduct + this->at(i, m) * rhs.at(m, j);
            }

            product.at(i, j) = dotProduct;
            dotProduct = 0;
        }
    }

    *this = product;
    return *this;
}

Matrix::Matrix Matrix::Matrix::operator*(const Matrix& rhs) {
    Matrix product(*this);
    product *= rhs;
    return product;
}

Matrix::Matrix& Matrix::Matrix::operator+=(const element_type& rhs) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < columns; ++j) {
            this->at(i, j) += rhs;
        }
    }

    return *this;
}

Matrix::Matrix Matrix::Matrix::operator+(const element_type& rhs) const {
    Matrix sum(*this);
    sum += rhs;
    return sum;
}

Matrix::Matrix& Matrix::Matrix::operator-=(const element_type& rhs) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < columns; ++j) {
            this->at(i, j) -= rhs;
        }
    }

    return *this;
}

Matrix::Matrix Matrix::Matrix::operator-(const element_type& rhs) const{
    Matrix difference(*this);
    difference -= rhs;
    return difference;
}

Matrix::Matrix& Matrix::Matrix::operator*=(const element_type& rhs) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < columns; ++j) {
            this->at(i, j) *= rhs;
        }
    }

    return *this;
}

Matrix::Matrix Matrix::Matrix::operator*(const element_type& rhs) const{
    Matrix product(*this);
    product *= rhs;
    return product;
}

Matrix::Matrix Matrix::operator+(const Matrix::element_type& lhs, const Matrix& rhs) {
    return rhs + lhs;
}

Matrix::Matrix Matrix::operator-(const Matrix::element_type& lhs, const Matrix& rhs) {
    return -rhs + lhs;
}

Matrix::Matrix Matrix::operator*(const Matrix::element_type& lhs, const Matrix& rhs) {
    return rhs * lhs;
}




