#include "ConstRowIterator.h"
#include "Matrix.h"

Matrix::ConstRowIterator::ConstRowIterator(const Matrix* matrix, int row) : matrix(matrix), row(row){

}

//// check
Matrix::ConstRowIterator::value_type Matrix::ConstRowIterator::operator*() const {
    return matrix->rowAt(row);
}

//// check
Matrix::ConstRowIterator::value_type Matrix::ConstRowIterator::operator[](int offset) const {
    return matrix->rowAt(row + offset);
}

Matrix::ConstRowIterator& Matrix::ConstRowIterator::operator++() {
    row++;
    return *this;
}

const Matrix::ConstRowIterator Matrix::ConstRowIterator::operator++(int) {
    ConstRowIterator moveElement(*this);
    ++(*this);
    return moveElement;
}

Matrix::ConstRowIterator& Matrix::ConstRowIterator::operator--() {
    row--;
    return *this;
}

const Matrix::ConstRowIterator Matrix::ConstRowIterator::operator--(int) {
    ConstRowIterator moveElement(*this);
    --(*this);
    return moveElement;
}

Matrix::ConstRowIterator& Matrix::ConstRowIterator::operator+=(int amount) {
    row += amount;
    return *this;
}

Matrix::ConstRowIterator Matrix::ConstRowIterator::operator+(int amount) const {
    ConstRowIterator moveElement(*this);
    moveElement.operator+=(amount);
    return moveElement;
}

Matrix::ConstRowIterator& Matrix::ConstRowIterator::operator-=(int amount) {
    row -= amount;
    return *this;
}

Matrix::ConstRowIterator Matrix::ConstRowIterator::operator-(int amount) const {
    ConstRowIterator moveElement(*this);
    moveElement.operator-=(amount);
    return moveElement;
}

Matrix::ConstRowIterator::difference_type Matrix::ConstRowIterator::operator-(const ConstRowIterator& rhs) {
    return row - rhs.row;
}

//Matrix::ConstRowIterator::operator bool() const {
//    return row >= 0 and row < matrix->getNumRows();
//}

bool Matrix::ConstRowIterator::operator==(const ConstRowIterator& rhs) const {
    return matrix == rhs.matrix and row == rhs.row;
}

bool Matrix::ConstRowIterator::operator!=(const ConstRowIterator& rhs) const {
    return !(*this == rhs);
}

bool Matrix::ConstRowIterator::operator<(const ConstRowIterator& rhs) const {
    return row < rhs.row;
}

bool Matrix::ConstRowIterator::operator<=(const ConstRowIterator& rhs) const {
    return row <= rhs.row;
}

bool Matrix::ConstRowIterator::operator>(const ConstRowIterator& rhs) const {
    return row > rhs.row;
}

bool Matrix::ConstRowIterator::operator>=(const ConstRowIterator& rhs) const {
    return row >= rhs.row;
}


