#ifndef ECS_36B_HOMEWORK_ROWITERATOR_H
#define ECS_36B_HOMEWORK_ROWITERATOR_H
#include <iterator>
#include "VectorRef.h"
#include "ConstVectorRef.h"
namespace Matrix {
  class Matrix;
  class ConstRowIterator;
  class RowIterator {
   public:
    //the iterator type tags
    using iterator_category = std::random_access_iterator_tag;
    using value_type = VectorRef;
    using difference_type = int;
    using pointer = const value_type*;
    using reference = const value_type&;

    //create a RowIterator over the specified matrix starting at the specified rows
    RowIterator(Matrix* matrix, int row);
    RowIterator(const RowIterator& orig) = default;
    virtual ~RowIterator() = default;

    //return a ConstRowIterator over the same matrix and at the same rows
    explicit operator ConstRowIterator() const;

    //return a reference to the rows that you are on
    ConstVectorRef operator* () const;
    value_type operator*();

    //return a reference to the rows offset past your current rows
    ConstVectorRef operator[](int offset) const;
    value_type operator[](int offset);

    //move to the next rows
    RowIterator& operator++(); //pre
    const RowIterator operator++(int); //post

    //move to the previous rows
    RowIterator& operator--(); //pre
    const RowIterator operator--(int); //post

    //move forward amount rows
    RowIterator& operator+=(int amount);
    RowIterator operator+(int amount) const;

    //move backward amount rows
    RowIterator& operator-=(int amount);
    RowIterator operator-(int amount) const;

    //return the number of rows between yourself and rhs
    //for example if you were at rows 10 and rhs was at rows 7
    //the difference would be 3
    difference_type operator-(const RowIterator& rhs);

//    explicit operator bool()const;

    //you are equal to rhs if you are both over the same matrix
    //and you are on the same rows
    bool operator==(const RowIterator& rhs) const;
    bool operator!=(const RowIterator& rhs) const;

    //are you at a rows before rhs?
    bool operator<(const RowIterator& rhs) const;
    bool operator<=(const RowIterator& rhs) const;

    //are you at a rows after rhs
    bool operator>(const RowIterator& rhs) const;
    bool operator>=(const RowIterator& rhs) const;

   protected:
    Matrix* matrix;
    int row;
  };
}

#endif //ECS_36B_HOMEWORK_ROWITERATOR_H
