#include "ConstColumnIterator.h"
#include "Matrix.h"

Matrix::ConstColumnIterator::ConstColumnIterator(const Matrix* matrix, int col) : matrix(matrix), column(col) {

}

Matrix::ConstColumnIterator::value_type Matrix::ConstColumnIterator::operator*() const {
    return matrix->colAt(column);
}

Matrix::ConstColumnIterator::value_type Matrix::ConstColumnIterator::operator[](int offset) const {
    return matrix->colAt(column + offset);
}

Matrix::ConstColumnIterator& Matrix::ConstColumnIterator::operator++() {
    column++;
    return *this;
}

const Matrix::ConstColumnIterator Matrix::ConstColumnIterator::operator++(int) {
    ConstColumnIterator moveElement(*this);
    ++(*this);
    return moveElement;
}

Matrix::ConstColumnIterator& Matrix::ConstColumnIterator::operator--() {
    column--;
    return *this;
}

const Matrix::ConstColumnIterator Matrix::ConstColumnIterator::operator--(int) {
    ConstColumnIterator moveElement(*this);
    --(*this);
    return moveElement;
}

Matrix::ConstColumnIterator& Matrix::ConstColumnIterator::operator+=(int amount) {
    column += amount;
    return *this;
}

Matrix::ConstColumnIterator Matrix::ConstColumnIterator::operator+(int amount) const {
    ConstColumnIterator moveElement(*this);
    moveElement.operator+=(amount);
    return moveElement;
}

Matrix::ConstColumnIterator& Matrix::ConstColumnIterator::operator-=(int amount) {
    column -= amount;
    return *this;
}

Matrix::ConstColumnIterator Matrix::ConstColumnIterator::operator-(int amount) const {
    ConstColumnIterator moveElement(*this);
    moveElement.operator-=(amount);
    return moveElement;
}

Matrix::ConstColumnIterator::difference_type Matrix::ConstColumnIterator::operator-(const ConstColumnIterator& rhs) {
    return column - rhs.column;
}

//Matrix::ColumnIterator::operator bool() const {
//    return column>= 0 and column < matrix->getNumRows();
//}

bool Matrix::ConstColumnIterator::operator==(const ConstColumnIterator& rhs) const {
    return matrix == rhs.matrix and column == rhs.column;
}

bool Matrix::ConstColumnIterator::operator!=(const ConstColumnIterator& rhs) const {
    return !(*this == rhs);
}

bool Matrix::ConstColumnIterator::operator<(const ConstColumnIterator& rhs) const {
    return column < rhs.column;
}

bool Matrix::ConstColumnIterator::operator<=(const ConstColumnIterator& rhs) const {
    return column <= rhs.column;
}

bool Matrix::ConstColumnIterator::operator>(const ConstColumnIterator& rhs) const {
    return column > rhs.column;
}

bool Matrix::ConstColumnIterator::operator>=(const ConstColumnIterator& rhs) const {
    return column >= rhs.column;
}

