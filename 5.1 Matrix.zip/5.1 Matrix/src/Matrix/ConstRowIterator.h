#ifndef ECS_36B_HOMEWORK_CONSTROWITERATOR_H
#define ECS_36B_HOMEWORK_CONSTROWITERATOR_H
#include <iterator>
#include "ConstVectorRef.h"
#include "Matrix.h"

namespace Matrix {
  class Matrix;
  class ConstRowIterator {
   public:
    //the iterator type tags
    using iterator_category = std::random_access_iterator_tag;
    using value_type = ConstVectorRef;
    using difference_type = int;
    using pointer = const value_type*;
    using reference = const value_type&;

    //Create an rows iterator over the specified Matrix starting at the specified rows
    ConstRowIterator(const Matrix* matrix, int row);
    ConstRowIterator(const ConstRowIterator& orig) = default;
    virtual ~ConstRowIterator() = default;

    //return a reference to the rows you are on
    value_type operator* () const;

    //return a reference to the rows offset rows past your current position
    value_type operator[](int offset) const;

    //move forward one rows
    ConstRowIterator& operator++(); //pre
    const ConstRowIterator operator++(int); //post

    //move backward one rows
    ConstRowIterator& operator--(); //pre
    const ConstRowIterator operator--(int); //post

    //move forward amount rows
    ConstRowIterator& operator+=(int amount);
    ConstRowIterator operator+(int amount) const;

    //move backward  rows
    ConstRowIterator& operator-=(int amount);
    ConstRowIterator operator-(int amount) const;

    //return the number of rows between yourself and rhs
    //for example if you were at rows 10 and rhs was at rows 7
    //the difference would be 3
    difference_type operator-(const ConstRowIterator& rhs);

//    explicit operator bool()const;

    //you are equal to rhs if you are both over the same matrix
    //and you are on the same rows
    bool operator==(const ConstRowIterator& rhs) const;
    bool operator!=(const ConstRowIterator& rhs) const;

    //are you at a rows before rhs?
    bool operator<(const ConstRowIterator& rhs) const;
    bool operator<=(const ConstRowIterator& rhs) const;

    //are you at a rows after rhs?
    bool operator>(const ConstRowIterator& rhs) const;
    bool operator>=(const ConstRowIterator& rhs) const;

   protected:
      const Matrix* matrix;
      int row;
  };
}

#endif //ECS_36B_HOMEWORK_CONSTROWITERATOR_H
