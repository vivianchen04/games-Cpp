#include "ColumnIterator.h"
#include "ConstColumnIterator.h"
#include "Matrix.h"

Matrix::ColumnIterator::ColumnIterator(Matrix* matrix, int col) : matrix(matrix), column(col) {

}

Matrix::ColumnIterator::operator ConstColumnIterator() const {
    return ConstColumnIterator(matrix, column);
}

Matrix::ConstVectorRef Matrix::ColumnIterator::operator*() const {
  return const_cast<const Matrix*>(matrix)->colAt(column);
}

////// TODO: check //////
Matrix::ColumnIterator::value_type Matrix::ColumnIterator::operator*() {
    return matrix->colAt(column);
}

Matrix::ConstVectorRef  Matrix::ColumnIterator::operator[](int offset) const {
  return const_cast<const Matrix*>(matrix)->colAt(column + offset);
}

////// TODO: check //////
Matrix::ColumnIterator::value_type Matrix::ColumnIterator::operator[](int offset) {
    return matrix->colAt(column + offset);
}

Matrix::ColumnIterator& Matrix::ColumnIterator::operator++() {
    column++;
    return *this;
}

const Matrix::ColumnIterator Matrix::ColumnIterator::operator++(int) {
    ColumnIterator moveElement(*this);
    ++(*this);
    return moveElement;
}

Matrix::ColumnIterator& Matrix::ColumnIterator::operator--() {
    column--;
    return *this;
}

const Matrix::ColumnIterator Matrix::ColumnIterator::operator--(int) {
    ColumnIterator moveElement(*this);
    --(*this);
    return moveElement;
}

Matrix::ColumnIterator& Matrix::ColumnIterator::operator+=(int amount) {
    column += amount;
    return *this;
}

Matrix::ColumnIterator Matrix::ColumnIterator::operator+(int amount) const {
    ColumnIterator moveElement(*this);
    moveElement.operator+=(amount);
    return moveElement;
}

Matrix::ColumnIterator& Matrix::ColumnIterator::operator-=(int amount) {
    column -= amount;
    return *this;
}

Matrix::ColumnIterator Matrix::ColumnIterator::operator-(int amount) const {
    ColumnIterator moveElement(*this);
    moveElement.operator-=(amount);
    return moveElement;
}

Matrix::ColumnIterator::difference_type Matrix::ColumnIterator::operator-(const ColumnIterator& rhs) {
    return column - rhs.column;
}

//Matrix::ColumnIterator::operator bool() const {
//    return column>= 0 and column< matrix->getNumRows();
//}

bool Matrix::ColumnIterator::operator==(const ColumnIterator& rhs) const {
    return matrix == rhs.matrix and column == rhs.column;
}

bool Matrix::ColumnIterator::operator!=(const ColumnIterator& rhs) const {
    return !(*this == rhs);
}

bool Matrix::ColumnIterator::operator<(const ColumnIterator& rhs) const {
    return column < rhs.column;
}

bool Matrix::ColumnIterator::operator<=(const ColumnIterator& rhs) const {
    return column <= rhs.column;
}

bool Matrix::ColumnIterator::operator>(const ColumnIterator& rhs) const {
    return column > rhs.column;
}

bool Matrix::ColumnIterator::operator>=(const ColumnIterator& rhs) const {
    return column >= rhs.column;
}
