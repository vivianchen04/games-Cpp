//
// Created by vivia on 4/21/2022.
//

#ifndef ROCKPAPERSCISSORS_MAIN_H
#define ROCKPAPERSCISSORS_MAIN_H

int main(int argc, char* argv[]);

#endif //ROCKPAPERSCISSORS_MAIN_H
