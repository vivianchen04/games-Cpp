#include <string>
#include <iostream>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <regex>

#include "ai.h"
#include "human.h"
#include "main.h"
#include "game.h"

int human_take_move() {
    std::string human_choice;
    int num;
           do {

                std::cout << "Enter (R)ock, (P)aper, or (S)cissors for your move: " ;
                getline(std::cin, human_choice);
                //human_choice = std::regex_replace(human_choice, std::regex("^ +| +$|( ) +"), "$1");
                std::stringstream line2parse(human_choice);
                line2parse >> num;
                if (line2parse) { //if I was able to read the number
                    std::string what_is_left;
                    line2parse >> what_is_left;
                    if (not line2parse) { //if there is nothing left we will fail to read it
                        return num;
                    }
                }

                std::for_each(human_choice.begin(), human_choice.end(), [](char & c){
                    c = tolower(c);
                });

          } while (!is_valid_move(human_choice));

            int human_choice_int = convert_choice_to_int(human_choice);
            return human_choice_int;
}

bool is_valid_move(std::string human_choice) {

    human_choice = std::regex_replace(human_choice, std::regex("^ +| +$|( ) +"), "$1");

    return (human_choice == "r") ||(human_choice == "(r)ock") ||(human_choice == "rock")||(human_choice == "p") ||
            (human_choice == "(p)aper") || (human_choice == "paper") ||(human_choice == "s") || (human_choice == "(s)cissors")
            ||(human_choice == "scissors");

}

int convert_choice_to_int (const std::string& human_choice){  //could it because I pass by reference?
    int human_choice_int;

    if ((human_choice == "r") ||(human_choice == "(r)ock")|| (human_choice == "rock")) {
        return human_choice_int = 0;
    }
    else if ((human_choice == "p")||(human_choice == "(p)aper")|| (human_choice == "paper")) {
        return human_choice_int = 1;
    }
    else {
        return human_choice_int = 2; // if ((human_choice == "s")||(human_choice == "(s)cissors")||(human_choice == "scissors"))
    }

}