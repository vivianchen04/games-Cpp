#ifndef ROCKPAPERSCISSORS_GAME_H
#define ROCKPAPERSCISSORS_GAME_H

void play_game(int human_choice_int, int ai_choice_int, std::minstd_rand& generator);
void keep_play_until_win(std::minstd_rand& generator);
void reply_game_after_win(std::minstd_rand& generator);
void check_reply_yes_or_no (const std::string& reply_char, std::minstd_rand& generator);
bool is_valid_reply(std::string reply_char);

#endif //ROCKPAPERSCISSORS_GAME_H
