#include <cstdio>
#include <string>
#include <iostream>
#include <cctype>
#include <algorithm>
#include <regex>
#include "ai.h"
#include "human.h"
#include "main.h"
#include "game.h"
#include <sstream>

void play_game(int human_choice_int, int ai_choice_int, std::minstd_rand& generator) {
    if (human_choice_int == 0) {
        if (ai_choice_int == 0) {
            std::cout << "You and the AI both played rock." << std::endl;
            keep_play_until_win(generator);
        } else if (ai_choice_int == 1) {
            std::cout << "The AI wins :(" << std::endl;
            reply_game_after_win(generator);
        } else if (ai_choice_int == 2) {
            std::cout << "You win!" << std::endl;
            reply_game_after_win(generator);
        }
    }

    else if (human_choice_int == 1) {
        if (ai_choice_int == 0) {
            std::cout << "You win!" << std::endl;
            reply_game_after_win(generator);
        } else if (ai_choice_int == 1) {
            std::cout << "You and the AI both played paper." << std::endl;
            keep_play_until_win(generator);
        } else if (ai_choice_int == 2) {
            std::cout << "The AI wins :(" << std::endl;
            reply_game_after_win(generator);
        }
    }

    else if (human_choice_int == 2) {
        if (ai_choice_int == 0) {
            std::cout << "The AI wins :(" << std::endl;
            reply_game_after_win(generator);
        } else if (ai_choice_int == 1) {
            std::cout << "You win!" << std::endl;
            reply_game_after_win(generator);
        } else if (ai_choice_int == 2) {
            std::cout << "You and the AI both played scissors." << std::endl;
            keep_play_until_win(generator);
        }
    }

    else {
        std::cout << "Something wrong with play_game";
    }

}


void keep_play_until_win(std::minstd_rand& generator) {
    std::cout << "Keep playing until someone wins." << std::endl;
    int human_choice_int = human_take_move();
    int ai_choice_int = getRandomInt(generator);
    play_game(human_choice_int, ai_choice_int, generator);


}

void reply_game_after_win(std::minstd_rand& generator) {
    std::string reply_char;
    int num;

    do {
        std::cout << "Would you like to replay the game?" << std::endl;
        std::cout << "Enter (Y)es or (N)o: ";
        getline(std::cin, reply_char);

        std::stringstream line2parse(reply_char);
        line2parse >> num;
        if (line2parse) { //if I was able to read the number
            std::string what_is_left;
            line2parse >> what_is_left;
            if (not line2parse) { //if there is nothing left we will fail to read it
                return;
            }
        }

        std::for_each(reply_char.begin(), reply_char.end(), [](char & c){
            c = tolower(c);
        });
        //check_reply_yes_or_no(reply_char, generator);

    } while(!is_valid_reply(reply_char));
    reply_char = std::regex_replace(reply_char, std::regex("^ +| +$|( ) +"), "$1");
    check_reply_yes_or_no(reply_char, generator);
}

void check_reply_yes_or_no (const std::string& reply_char, std::minstd_rand& generator) {

    if (reply_char == "y"||reply_char == "(y)es" || reply_char == "yes") {
        int human_choice_int = human_take_move();
        int ai_choice_int = getRandomInt(generator);
        play_game(human_choice_int, ai_choice_int, generator);

    } else {
        return;
    }
}


bool is_valid_reply(std::string reply_char) {

    reply_char = std::regex_replace(reply_char, std::regex("^ +| +$|( ) +"), "$1");

    return (reply_char == "y") ||(reply_char == "(y)es") ||(reply_char == "yes")||(reply_char == "n") ||
            (reply_char == "(n)o") || (reply_char == "no") ;

}
