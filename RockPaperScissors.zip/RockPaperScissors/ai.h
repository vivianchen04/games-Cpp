//
// Created by vivia on 4/21/2022.
//

#ifndef ROCKPAPERSCISSORS_AI_H
#define ROCKPAPERSCISSORS_AI_H
#include <random>
#include <iterator>
#include <vector>
#include <ostream>


int minstd_get_random_int(int min , int max , std::minstd_rand& generator);

int getRandomInt(std::minstd_rand& generator);

//template<typename RandomNumberGenerator>
//int getRandom_Int(int min, int max, RandomNumberGenerator& rng) {
//    std::uniform_int_distribution<int> dist(min, max);
//    int random_num = dist(rng);
//    return random_num;
//}

void print_ai_choice(int ai_random);

#endif //ROCKPAPERSCISSORS_AI_H
