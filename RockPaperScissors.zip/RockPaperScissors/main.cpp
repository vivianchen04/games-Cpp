#include <cstdio>
#include <iostream>
#include <string>
#include <chrono>
#include "ai.h"
#include "human.h"
#include "game.h"


int main(int argc, char* argv[]){
    int seed;
    int human_choice_int;
    int ai_choice_int;

    if (argc == 2) {
        seed = std::stoi(argv[1]); // the first argument is the seed to randomized
        human_choice_int = human_take_move();
        std::minstd_rand generator(seed);
        ai_choice_int = getRandomInt(generator);
        play_game(human_choice_int, ai_choice_int, generator);


    } else {
        // the first argument is null then use the current time
        seed = std::chrono::system_clock::now().time_since_epoch().count();
        human_choice_int = human_take_move();
        std::minstd_rand generator(seed);
        ai_choice_int = getRandomInt(generator);
        play_game(human_choice_int, ai_choice_int, generator);

    }
    return 0;
}


