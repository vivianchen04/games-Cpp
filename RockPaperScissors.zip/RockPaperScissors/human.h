
#ifndef ROCKPAPERSCISSORS_HUMAN_H
#define ROCKPAPERSCISSORS_HUMAN_H

bool is_valid_move(std::string human_choice);

int human_take_move();

int convert_choice_to_int (const std::string& human_choice);


#endif //ROCKPAPERSCISSORS_HUMAN_H
