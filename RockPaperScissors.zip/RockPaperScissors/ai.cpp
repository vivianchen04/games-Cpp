#include <cstdio>
#include <iostream>
#include <string>
#include <chrono>
#include "ai.h"

// passing reference of generator
int minstd_get_random_int(int min, int max, std::minstd_rand& generator) {
    std::uniform_int_distribution<int> dist(min, max);
    int random_num = dist(generator);
    return random_num;
}

int getRandomInt(std::minstd_rand& generator) {
    //std::minstd_rand generator(seed);  //if I put a generator here should I get different time
    int ai_random = minstd_get_random_int(0, 2, generator);  // this is the ai random number I get
    print_ai_choice (ai_random);
    return ai_random;
}

//int getRandomInt(int seed) {
//    std::minstd_rand generator(seed);
//    int ai_random = getRandom_Int(0, 2, generator);
//    return ai_random;
//
//}

void print_ai_choice(int ai_random){
    if (ai_random == 0) {
        std::cout << "The ai played rock." << std::endl;
    } else if (ai_random == 1) {
        std::cout << "The ai played paper." << std::endl;
    } else {
        std::cout << "The ai played scissors." << std::endl;
    }

}
