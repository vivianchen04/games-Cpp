//
// Created by mfbut on 4/4/2021.
//

#include "gtest/gtest.h"
#include "sorting.h"

TEST(GetSortedTests, SortArray){
    /*
     * See that the array was successfully sorted.
     * Don't forget to free any memory that was dynamically allocated as part of your test.
     */
    int array[] = {30,20,10,40};
    int sorted_array[] = {10,20,30,40};;
    int length = sizeof(array)/sizeof array[0];
    int *new_array = get_sorted(array, length);
    for (int i = 0; i< length; i++){
        EXPECT_EQ(new_array[i],sorted_array[i]);
    }
    free(new_array);

}

TEST(GetSortedTests, CopyWasMade){
  /*
   * Check that the sorted array is copy of the original array in sorted order.
   * (ar and copy point to different locations in memory and no parts of the two arrays overlap)
   * Don't forget to free any memory that was dynamically allocated.
   * Don't forget to free any memory that was dynamically allocated as part of your test.
   */
    int array[] = {20,10,40,30};
    int orig_sorted_array[] = {10,20,30,40};
    int length = sizeof(array)/sizeof array[0];
    int* sorted_array = get_sorted(array, length);
    for (int i = 0; i< length; i++){
        EXPECT_EQ(orig_sorted_array[i],sorted_array[i]);
    }
    free(sorted_array);

}

TEST(GetSortedTests, OriginalDoesNotChange){
  /*
   * Check that the original array was not modified.
   * Don't forget to free any memory that was dynamically allocated as part of your test.
   */
    int array[] = {20,10,40,30};
    int copy_array[] = {20,10,40,30};
    int length = sizeof(array)/sizeof array[0];
    int* sorted_array = get_sorted(array, length);
    for (int i = 0; i< length; i++){
        EXPECT_EQ(array[i],copy_array[i]);
    }
    free(sorted_array);

}

TEST(GetSortedTests, SortSortedArray){
  /*
   * Check that we can sort an array that is already sorted.
   * Don't forget to free any memory that was dynamically allocated as part of your test.
   */
    int array[] = {10,20,30,40};
    int length = sizeof(array)/sizeof array[0];
    int* sorted_array = get_sorted(array, length);
    for (int i = 0; i< length; i++){
        EXPECT_EQ(array[i],sorted_array[i]);
    }
    free(sorted_array);
}

TEST(GetSortedTests, SortReverseSortedArray){
  /*
   * Check that we can sort an array that is reverse sorted order.
   * Don't forget to free any memory that was dynamically allocated as part of your test.
   */
    int array[] = {40,30,20,10};
    int correct[] = {10,20,30,40};
    int length = sizeof(array)/sizeof array[0];
    int* sorted_array = get_sorted(array, length);
    for (int i = 0; i< length; i++){
        EXPECT_EQ(sorted_array[i],correct[i]);
    }
    free(sorted_array);

}

TEST(GetSortedTests, SortAverageArray){
  /*
   * Check that we can sort an array where the elements in it are in random order.
   * Don't forget to free any memory that was dynamically allocated as part of your test.
   */
  int array[] = {20,30,10,40};
  int correct[] = {10,20,30,40};
    int length = sizeof(array)/sizeof array[0];
    int* sorted_array = get_sorted(array, length);
    for (int i = 0; i< length; i++){
        EXPECT_EQ(sorted_array[i],correct[i]);
    }
    free(sorted_array);

}


TEST(GetSortedTests, SortArrayWithDuplicates){
  /*
   * Check that we can sort an array where there are duplicate elements in it.
   * Don't forget to free any memory that was dynamically allocated as part of your test.
   */
    int array[] = {10,30,20,20,40};
    int correct[]={10,20,20,30,40};
    int length = sizeof(array)/sizeof array[0];
    int* sorted_array = get_sorted(array, length);
    for (int i = 0; i< length; i++){
        EXPECT_EQ(sorted_array[i],correct[i]);
    }
    free(sorted_array);

}


