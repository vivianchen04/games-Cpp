//
// Created by mfbut on 4/4/2021.
//

#include "gtest/gtest.h"
#include "sorting.h"
#include "formatting.h"
#include "test_helpers.h"

TEST(CopyArrayTests, CopyWasMade){
  /*
   * Check that a copy was actually made
   * (ar and copy point to different locations in memory and no parts of the two arrays overlap)
   * Don't forget to free any memory that was dynamically allocated.
   * Don't forget to free any memory that was dynamically allocated as part of your test.
   */
  int array[] = {30,40,10,20};
  int size = sizeof(array)/sizeof array[0];
  int* copy = copy_array(array, size);
  for (int i = 0; i < size; i++) {
      EXPECT_NE(&array[i],&copy[i]);
  }
  free(copy);

}

TEST(CopyArrayTests, ValuesAreSame){
  /*
   * Check that the values in the copy are the same as the values in the original array.
   * Don't forget to free any memory that was dynamically allocated as part of your test.
   */
  int arr1[] = {10,30,40,20};
  int n = sizeof(arr1) / sizeof(int);
  int* arr2 = copy_array(arr1, n);
  int m = 4;
  ASSERT_EQ(n,m);
  for (int i = 0; i< n; i++){
      EXPECT_EQ(arr1[1],arr2[1]);
  }
  free(arr2);

}

TEST(CopyArrayTests, OriginalDoesNotChange){
  /*
   * Check that the values in the original array did not change.
   * Don't forget to free any memory that was dynamically allocated as part of your test.
   */
   int arr1[] = {10,30,40,20};
   int correct[] = {10,30,40,20};
   int n = sizeof(arr1)/sizeof(int);
   int m = sizeof(correct)/sizeof(int);
   int* arr2 = copy_array(arr1, n);
    ASSERT_EQ(n,m);
    for (int i = 0; i< n; i++){
        EXPECT_EQ(arr2[1],correct[1]);
    }
    free(arr2);
}


