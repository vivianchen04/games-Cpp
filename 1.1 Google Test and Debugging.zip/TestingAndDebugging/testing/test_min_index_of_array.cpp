//
// Created by mfbut on 4/4/2021.
//
#include "gtest/gtest.h"
#include "sorting.h"

TEST(MinIndexOfArrayTests, MinIndexAtFrontOfArray){
/*
 * See if we can find the index of the minimum value when it is at the front of the array
 */
    int array[] = {5,30,20,40,50};
    int length = sizeof(array)/sizeof array[0];
    int min = min_index_of_array(array, length);
    ASSERT_EQ(min, 0);
}

TEST(MinIndexOfArrayTests, MinIndexAtEndOfArray){
/*
 * See if we can find the index of the minimum value when it is at the end of the array
 */
    int array[] = {30,20,40,50,5};
    int length = sizeof(array)/sizeof array[0];
    int min = min_index_of_array(array, length);
    ASSERT_EQ(min,4);
}

TEST(MinIndexOfArrayTests, MinIndexAtMiddleOfArray){
/*
 * See if we can find the index of the minimum value when it is somewhere
 * in the "middle" of the array.
 */
    int array[] = {30,20,5,40,50,};
    int length = sizeof(array)/sizeof array[0];
    int min = min_index_of_array(array, length);
    ASSERT_EQ(min,2);
}

TEST(MinIndexOfArrayTests, DuplicateMinimums){
/*
 * See if we return the index of the first minimum in the array
 * When there are multiple values that are the minimum.
 */
    int array[] = {30,5,20,40,50,5};
    int length = sizeof(array)/sizeof array[0];
    int min = min_index_of_array(array, length);
    ASSERT_EQ(min, 1);
}

TEST(MinIndexOfArrayTests, ArrayDoesNotChange){
/*
 * Check that finding the minimum of the array did not change the contents of the array.
 */
    int array[] = {30,5,20,40,50,5};
    int length = sizeof(array)/sizeof array[0];
    int min = min_index_of_array(array, length);
    ASSERT_EQ(min, 1);
    int true_arr[] =  {30,5,20,40,50,5};
    for(int i = 0; i< length; i++){
        EXPECT_EQ(array[i],true_arr[i]);
    }
}
