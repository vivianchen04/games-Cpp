//
// Created by mfbut on 4/4/2021.
//
#include "gtest/gtest.h"
#include "formatting.h"


TEST(ParseArgsTests, CheckArgumentsParsedSuccessfully){
    /*
     * Check that you parse the command line arguments correctly.
     * (ar_out and len_out are set to the right values).
     * Don't forget to free any memory that was dynamically allocated as part of your test.'
     */

    char arg1[] = "Program";
    char arg2[] = "1";
    char arg3[] = "2";
    char arg4[] = "3";

    char* argv[] = {arg1,arg2,arg3,arg4};

    //const char* argv[] = {"1","2","3"};
    int correct[] = {1,2,3};
    int argc = 4;
    int len_out;
    int* ar_out = nullptr;
    parse_args(argc, argv, &ar_out, &len_out);
    for (int i = 0; i<argc-1; i++){
        EXPECT_EQ(ar_out[i], correct[i]);
    }
    ASSERT_EQ(len_out+1, argc);
}

TEST(ParseArgsTests, CheckParseNoArgs){
    /*
     * Check that you parse you can successfully parse "no" command line arguments.
     */

    char arg1[] = "Program";
    char* argv[] = {arg1};
    int argc = 1;
    int len_out;
    int* ar_out = nullptr;
    parse_args(argc, argv, &ar_out, &len_out);
    ASSERT_EQ(ar_out, nullptr);
}