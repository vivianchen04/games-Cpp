//
// Created by mfbut on 4/4/2021.
//

#include "gtest/gtest.h"
#include "sorting.h"
#include "test_helpers.h"
#include <cstdio>
#include <cstdlib>

TEST(SwapTests, SwapTwoValues){
  /*
   * Swap two values and see if the swap was successful.
   */
    int a = 3;
    int b = 4;
    swap(&a,&b);
    ASSERT_EQ(a,4);
    ASSERT_EQ(b,3);
}

TEST(SwapTests, SwapValuesInArray){
  /*
   * Swap a few values in an array.
   * Check that the ones that swapped did swap and the ones that didn't swap
   * are still at the same locations
   */
    int arr_before[] = { 10, 20, 30, 40 ,50};
    int arr_after[] = {20,10,40,30,50};
    swap(&arr_before[0],&arr_before[1]);
    swap(&arr_before[2],&arr_before[3]);
    int length = sizeof(arr_before)/sizeof arr_before[0];
    for (int i = 0; i< length; i++){
        EXPECT_EQ(arr_before[i], arr_after[i]);
    }
}


