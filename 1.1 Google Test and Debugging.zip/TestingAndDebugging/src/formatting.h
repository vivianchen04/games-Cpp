//
// Created by mfbut on 4/3/2021.
//

#ifndef TESTINGANDDEBUGGING_FORMATTING_H
#define TESTINGANDDEBUGGING_FORMATTING_H
void print_ar(int* ar, int len);
void parse_args(int argc, char** argv, int** ar_out, int* len_out);


#endif //TESTINGANDDEBUGGING_FORMATTING_H
