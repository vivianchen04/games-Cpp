//
// Created by mfbut on 4/3/2021.
//

#ifndef TESTINGANDDEBUGGING_SORTING_H
#define TESTINGANDDEBUGGING_SORTING_H
int* get_sorted(int* ar, int len);
void make_sorted(int* ar, int len);
int* copy_array(int * ar, int len);
int min_index_of_array(int* ar, int len);
void swap(int* a, int* b);

#endif //TESTINGANDDEBUGGING_SORTING_H
