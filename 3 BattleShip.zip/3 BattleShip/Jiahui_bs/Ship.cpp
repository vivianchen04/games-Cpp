//
// Created by sunji on 5/8/2022.
//

#include <sstream>
#include "Ship.h"

char BattleShip::Ship::getDirection(const std::string& prompt, std::istream& in, std::ostream& out) {
    std::string inputLine;
    while (true) {
        out << prompt;
        std::getline(in, inputLine);
        std::stringstream lineBreak(inputLine);
        char direction;
        lineBreak >> direction;
        if (lineBreak) {
            std::string inputLeft;
            lineBreak >> inputLeft;
            if (not lineBreak) {
                return direction;
            }
        }
    }
}

void BattleShip::Ship::getRowAndColumn(const std::string& prompt, int& row, int& column, std::istream& in, std::ostream& out) {
    std::string inputLine;
    while (true) {
        out << prompt;
        std::getline(in, inputLine);
        std::stringstream lineBreak(inputLine);
        lineBreak >> row >> column;
        if (lineBreak and isStreamEmpty(lineBreak)) {
            return;
        }
    }

}


bool BattleShip::Ship::isStreamEmpty(std::istream& in) {
    std::string inputLineLeft;
    in >> inputLineLeft;
    return not in;
}
