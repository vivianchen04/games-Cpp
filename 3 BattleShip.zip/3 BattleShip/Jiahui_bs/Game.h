//
// Created by sunji on 5/8/2022.
//

#ifndef BATTLESHIP_GAME_H
#define BATTLESHIP_GAME_H

#include <vector>
#include "Ship.h"
#include "Player.h"

namespace BattleShip {
    class Game {
    public:

        Game();

        setUp(std::ifstream& inputFile, const std::string& fileName);

        void play(std::istream& in = std::cin, std::ostream& out = std::cout);

    private:

        bool isGameOver() const;

        void playARound(int& rows, int& columns, std::istream& in, std::ostream& out);

        void declareResults(std::ostream& out) const;

        void chooseAPointToFire(int& row, int& column, std::istream& in = std::cin, std::ostream& out = std::cout);

        bool isStreamEmpty(std::istream& in);

        void changeTurnToAnotherPlayer(int& turn);

        void displayFiringBoard(int rows, int columns, std::ostream& out);

        void
        displayPlacementBoard(int rows, int columns, std::ostream& out);

        std::vector<std::vector<std::string>> loadFileToSetUp(std::ifstream& inputFile, const std::string& fileName);

        void setUpBoards(std::vector<std::vector<std::string>> inputVector);

        std::map<std::string, int> setUpShips(std::vector<std::vector<std::string>> inputVector);


        std::vector<std::vector<char>>& firingBoardVector;
        std::vector<std::vector<char>>& placementBoardVector;
        std::vector<Player> players;
        std::vector<Ship> ships;
    };
}

#endif //BATTLESHIP_GAME_H
