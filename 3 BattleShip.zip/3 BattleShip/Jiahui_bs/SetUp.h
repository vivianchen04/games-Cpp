//
// Created by sunji on 5/8/2022.
//

#ifndef BATTLESHIP_SETUP_H
#define BATTLESHIP_SETUP_H

namespace BattleShip {

        void openFile(std::ifstream &inputFile, const std::string &fileName);

        std::vector<std::vector<std::string>> readFileToSetUp(std::ifstream &inputFile);

        std::vector<std::vector<char>> setUpBoard(std::vector<std::vector<std::string>> inputVector);

        std::map<std::string, int> setUpShip(std::vector<std::vector<std::string>> inputVector);
}

#endif //BATTLESHIP_SETUP_H
