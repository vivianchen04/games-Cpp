//
// Created by sunji on 5/8/2022.
//

#ifndef BATTLESHIP_BOARD_H
#define BATTLESHIP_BOARD_H

namespace BattleShip {
    class Board {
    public:
        Board();

    private:
        PlacementBoard;

    };
}

#endif //BATTLESHIP_BOARD_H
