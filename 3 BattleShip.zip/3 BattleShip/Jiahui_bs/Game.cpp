//
// Created by sunji on 5/8/2022.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include "Game.h"


void BattleShip::Game::setUp(std::ifstream& inputFile, const std::string& fileName) {
    std::vector<std::vector<std::string>> inputVector;

    inputVector = loadFileToSetUp(inputFile, fileName);
    setUpBoards(inputVector);
    setUpShips(inputVector);
}

void BattleShip::Game::play(std::istream& in, std::ostream& out) {
    while (not isGameOver()) {
        playARound(row, column, in, out);
    }
    declareResults(out);
}

bool BattleShip::Game::isGameOver() const {
    // The game is over when there is no ship on the placement board
    return ships.size() == 0;
}

void BattleShip::Game::playARound(int& rows, int& columns, std::istream& in, std::ostream& out) {
    int currentPlayerTurn = 0;

    displayFiringBoard(rows, columns, out);
    displayPlacementBoard(rows, columns, out);
    chooseAPointToFire(rows, columns, in, out);
    updateFiringBoard();
    updatePlavementBoard();
    displayFiringBoard(rows, columns, out);
    displayPlacementBoard(rows, columns, out);
    changeTurnToAnotherPlayer(currentPlayerTurn);
}

void BattleShip::Game::declareResults(std::ostream& out) const{
    out << players.getName() << " won the game!" << std::endl;
}

void BattleShip::Game::changeTurnToAnotherPlayer(int& turn) {
    turn = (turn + 1) % players.size();
}

void BattleShip::Game::displayFiringBoard(int rows, int columns, std::ostream& out) {

    out << "  ";
    for (int i = 0; i < columns; ++i) {
        out << i;
    }
    out << std::endl;

    for (int m = 0; m < rows; ++m) {
        out << m << " ";
        for (auto point : firingBoardVector.at(m)) {
            out << point;
        }
        out << std::endl;
    }
}

void BattleShip::Game::displayPlacementBoard(int rows, int columns, std::ostream& out) {
    out << "  ";
    for (int i = 0; i < columns; ++i) {
        out << i;
    }
    out << std::endl;

    for (int m = 0; m < rows; ++m) {
        out << m << " ";
        for (auto point : placementBoardVector.at(m)) {
            out << point;
        }
        out << std::endl;
    }
}

void BattleShip::Game::chooseAPointToFire(int& row, int& column, std::istream& in,
                                          std::ostream& out) {
    std::string inputLine;
    while (true) {
        out << players.getName() << ", where would you like to fire? Enter your attack coordinate in the form row col: ";
        std::getline(in, inputLine);
        std::stringstream lineBreak(inputLine);
        lineBreak >> row >> column;
        if (lineBreak and isStreamEmpty(lineBreak)) {
            return;
        }
    }
}

bool BattleShip::Game::isStreamEmpty(std::istream& in) {
    std::string inputLineLeft;
    in >> inputLineLeft;
    return not in;
}

std::vector<std::vector<std::string>> BattleShip::Game::loadFileToSetUp(std::ifstream& inputFile, const std::string& fileName) {
    inputFile.open(fileName);

    if (!inputFile.is_open()){
        std::cout << "Cannot open file." << std::endl;
        exit(-1);
    }

    std::string line;
    std::vector<std::vector<std::string>> inputVector;

    while(std::getline(inputFile, line)) {
        std::vector<std::string> lineVector;
        std::string inputString;

        std::istringstream ss(line);
        while(ss >> inputString) {
            lineVector.push_back(inputString);
        }
        inputVector.push_back(lineVector);
    }
    return inputVector;
}

void BattleShip::Game::setUpBoards(std::vector<std::vector<std::string>> inputVector) {
    int boardRow;
    int boardColumn;

    boardRow = stoi(inputVector.at(0).at(0));
    boardColumn = stoi(inputVector.at(1).at(0));

    std::vector<std::vector<char>> boardVector(boardRow, std::vector<char>(boardColumn, '*'));

    firingBoardVector = boardVector;
    placementBoardVector = boardVector;
}

std::map<std::string, int> BattleShip::Game::setUpShips(std::vector<std::vector<std::string>> inputVector) {
//    int numOfShip;
//    numOfShip = stoi(inputVector.at(2).at(0));

    std::map<std::string, int> shipMap;

    for (int i = 3; i < inputVector.size(); ++i) {
        std::string shipName;
        int shipLength;

        shipName = inputVector.at(i).at(0);
        shipLength = stoi(inputVector.at(i).at(1));

        shipMap.insert({shipName, shipLength});
    }

    return shipMap;
}


