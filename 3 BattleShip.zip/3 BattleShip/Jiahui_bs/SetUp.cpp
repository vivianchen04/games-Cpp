//
// Created by sunji on 5/8/2022.
//

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "SetUp.h"



void BattleShip::openFile(std::ifstream& inputFile, const std::string& fileName) {
    inputFile.open(fileName);

    if (!inputFile.is_open()){
        std::cout << "Cannot open file." << std::endl;
        exit(-1);
    }
}


std::vector<std::vector<std::string>> BattleShip::readFileToSetUp(std::ifstream& inputFile) {
    std::string line;
    std::vector<std::vector<std::string>> inputVector;

    while(std::getline(inputFile, line)) {
        std::vector<std::string> lineVector;
        std::string inputString;

        std::istringstream ss(line);
        while(ss >> inputString) {
            lineVector.push_back(inputString);
        }
        inputVector.push_back(lineVector);
    }

    return inputVector;
}


std::vector<std::vector<char>> BattleShip::setUpBoard(std::vector<std::vector<std::string>> inputVector) {
    int boardRow;
    int boardColumn;

    boardRow = stoi(inputVector.at(0).at(0));
    boardColumn = stoi(inputVector.at(1).at(0));

    std::vector<std::vector<char>> boardVector (boardRow, std::vector<char>(boardColumn, '*'));
    //TODO:add x and y axis to matrix

    return boardVector;
}


std::map<std::string, int> BattleShip::setUpShip(std::vector<std::vector<std::string>> inputVector) {
//    int numOfShip;
//    numOfShip = stoi(inputVector.at(2).at(0));
    
    std::map<std::string, int> shipMap;

    for (int i = 3; i < inputVector.size(); ++i) {
        std::string shipName;
        int shipLength;

        shipName = inputVector.at(i).at(0);
        shipLength = stoi(inputVector.at(i).at(1));

        shipMap.insert({shipName, shipLength});
    }

    return shipMap;
}