//
// Created by sunji on 5/8/2022.
//

#ifndef BATTLESHIP_PLAYER_H
#define BATTLESHIP_PLAYER_H

#include <vector>
#include <string>

namespace BattleShip {
    class Player {
        public:
            Player() = delete;
            Player();


        private:
            std::string name;


    };
}


#endif //BATTLESHIP_PLAYER_H
