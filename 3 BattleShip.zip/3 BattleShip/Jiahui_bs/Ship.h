//
// Created by sunji on 5/8/2022.
//

#ifndef BATTLESHIP_SHIP_H
#define BATTLESHIP_SHIP_H


#include <string>
#include <iostream>

namespace BattleShip {
    class Ship {
    public:
        bool isStreamEmpty(std::istream& in);

        char getDirection(const std::string& prompt, std::istream& in, std::ostream& out);

        void getRowAndColumn(const std::string& prompt, int& row, int& column, std::istream& in = std::cin, std::ostream& out = std::cout);

    };
}

#endif //BATTLESHIP_SHIP_H
