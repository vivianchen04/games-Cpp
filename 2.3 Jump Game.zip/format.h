//
// Created by sunji on 4/25/2022.
//

#ifndef INC_2_3_JUMP_GAME_FORMAT_H
#define INC_2_3_JUMP_GAME_FORMAT_H


std::vector<int> stringToNumeric(int argc, char **argv);
void printSteps(const std::vector<int>& minVector);


#endif //INC_2_3_JUMP_GAME_FORMAT_H
