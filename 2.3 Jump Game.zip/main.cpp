#include <iostream>
#include <vector>
#include <map>
#include "jump.h"
#include "format.h"
#include "sort.h"


int main(int argc, char** argv) {
    if (argc < 2) {
        std::cout << "There is no solution to the given game." << std::endl;
        return -1;
    }


    std::vector<std::vector<int>> multipleWays;
    std::vector<int> currentWay;
    int index = 0;

    auto givenNumVector = stringToNumeric(argc, argv);

    jumpSteps(givenNumVector, multipleWays, currentWay, index);


    if (multipleWays.size() != 0) {

        auto stepsMap = waysAndSize(multipleWays);

        auto minStepsVector = minimumWay(stepsMap);

        printSteps(minStepsVector);

    } else {
        std::cout << "There is no solution to the given game." << std::endl;
    }



    return 0;

}

