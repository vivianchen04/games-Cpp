//
// Created by sunji on 4/26/2022.
//

#ifndef INC_2_3_JUMP_GAME_SORT_H
#define INC_2_3_JUMP_GAME_SORT_H


std::map<std::vector<int>, int> waysAndSize(std::vector<std::vector<int>> &multipleWays);
std::vector<int> minimumWay(std::map<std::vector<int>, int> &stepsMap);


#endif //INC_2_3_JUMP_GAME_SORT_H
