#include <vector>
#include <algorithm>
#include "jump.h"



void jumpSteps(const std::vector<int> &givenNumVector, std::vector<std::vector<int>> &multipleWays,
                                        std::vector<int> currentWay, int currentIndex) {

    int lastElementIndex = givenNumVector.size() - 1;

    int movement = givenNumVector.at(currentIndex);
    int leftMovingIndex = currentIndex - movement;
    int rightMovingIndex = currentIndex + movement;



    if (currentIndex == lastElementIndex) { // exit when reach the last index
        currentWay.push_back(currentIndex); // add the last element index to the vector
        multipleWays.push_back(currentWay); // collect all the ways

        return;
    }


    int currentWaySize = currentWay.size();
    for (int i = 0; i < currentWaySize; ++i) {
        if (currentIndex == currentWay.at(i))
            return;

}


    currentWay.push_back(currentIndex); // add current index to the vector


    if (leftMovingIndex >= 0 ) {

//        auto indexIterator = find(currentWay.begin(), currentWay.end(), leftMovingIndex);
//        if (indexIterator == currentWay.end()) { }// check it's repeated step
        currentIndex = leftMovingIndex;
        jumpSteps(givenNumVector, multipleWays, currentWay, currentIndex);


    }


    if (rightMovingIndex <= lastElementIndex) {

//        auto indexIterator = find(currentWay.begin(), currentWay.end(), rightMovingIndex);
//        if (indexIterator == currentWay.end()) {}
        currentIndex = rightMovingIndex;
        jumpSteps(givenNumVector, multipleWays, currentWay, currentIndex);

    }


    if ((leftMovingIndex <= 0) && (rightMovingIndex > lastElementIndex)) {
        return;
    }

}

