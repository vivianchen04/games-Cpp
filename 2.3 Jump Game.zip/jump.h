//
// Created by sunji on 4/24/2022.
//

#ifndef INC_2_3_JUMP_GAME_JUMP_H
#define INC_2_3_JUMP_GAME_JUMP_H


void jumpSteps(const std::vector<int> &givenNumVector, std::vector<std::vector<int>> &multipleWays,
                                        std::vector<int> currentWay, int currentIndex);


#endif //INC_2_3_JUMP_GAME_JUMP_H
