#include <vector>
#include <map>
#include "sort.h"



std::map<std::vector<int>, int> waysAndSize(std::vector<std::vector<int>> &multipleWays) {
    std::map<std::vector<int>, int> stepsMap;

    int multipleWaysSize = multipleWays.size();
    for (int i = 0; i < multipleWaysSize; ++i) {
        const auto& way = multipleWays.at(i);
        const int& waySize = multipleWays.at(i).size();

        stepsMap.insert({way, waySize});
    }

    return stepsMap;

}




std::vector<int> minimumWay(std::map<std::vector<int>, int> &stepsMap) {

    int numOfMinSteps = stepsMap.begin()->second; // set first value be min number of step
    std::vector<int> minSteps = stepsMap.begin()->first;

//    auto mapIterator = stepsMap.begin();
//    if (mapIterator != stepsMap.end())

    for (const auto& mapIterator : stepsMap) {
        int numSteps = mapIterator.second;
        if (numSteps < numOfMinSteps) {
            numOfMinSteps = numSteps;
            minSteps = mapIterator.first;
        }
    }

    return minSteps;
}
