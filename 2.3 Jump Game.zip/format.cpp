#include <cstdlib>
#include <iostream>
#include <vector>
#include "format.h"



std::vector<int> stringToNumeric(int argc, char **argv) {

    std::vector<int> givenNumVector;

    int num;
    for (int i = 1; i < argc; ++i) {

        num = atoi(argv[i]);
        givenNumVector.push_back(num);
    }

    return givenNumVector;

}



void printSteps(const std::vector<int> &minVector) {
    int minVectorSize = minVector.size();
    if (minVectorSize == 0) {
        std::cout << "There is no solution to the given game." << std::endl;
    } else {
        std::cout << "The solution is: {";
        for (int i = 0; i < minVectorSize; ++i) {
            std::cout << minVector.at(i);
            if (i != minVectorSize - 1) {
                std::cout << ", ";
            }
        }
        std::cout << "}" << std::endl;
    }
}


//void stringToNumeric(int argc, char **argv, int **numArray, int *length) {
//    *length = argc - 1;
//    if (*length < 1) {
//        *numArray = NULL;
//    }
//
//    *numArray = (int*) malloc(*length);
//
//    for (int i = 0; i < *length; ++i) {
//        *numArray = (int*) argv[i];
//    }
//
//}
