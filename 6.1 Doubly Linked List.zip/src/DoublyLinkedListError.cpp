#include <sstream>
#include "DoublyLinkedListError.h"

const char* DoublyLinkedListError::what() const noexcept{
    return errorString.c_str();
}

DoublyLinkedListError::DoublyLinkedListError() noexcept {
    std::stringstream errorStream;
    errorStream << "Doubly linked list has error." << std::endl;
    errorString = errorStream.str();
}
