#ifndef TESTDOUBLELINKEDLIST_DOUBLYLINKEDLISTERROR_H
#define TESTDOUBLELINKEDLIST_DOUBLYLINKEDLISTERROR_H

#include <string>

class DoublyLinkedListError : public std::exception {
     public:
        DoublyLinkedListError() noexcept;
        virtual const char* what() const noexcept override;

     protected:
         std::string errorString;
};

#endif //TESTDOUBLELINKEDLIST_DOUBLYLINKEDLISTERROR_H
