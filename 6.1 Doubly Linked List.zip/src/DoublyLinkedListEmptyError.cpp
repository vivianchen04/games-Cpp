#include <sstream>
#include "DoublyLinkedListEmptyError.h"

DoublyLinkedListEmptyError::DoublyLinkedListEmptyError() {
    std::stringstream errorStream;
    errorStream << "Cannot get a reference is due to an empty double linked list." << std::endl;
    errorString = errorStream.str();
}
