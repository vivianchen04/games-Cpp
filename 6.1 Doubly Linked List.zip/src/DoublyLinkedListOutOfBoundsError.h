#ifndef TESTDOUBLELINKEDLIST_DOUBLYLINKEDLISTOUTOFBOUNDSERROR_H
#define TESTDOUBLELINKEDLIST_DOUBLYLINKEDLISTOUTOFBOUNDSERROR_H

#include "DoublyLinkedListError.h"

class DoublyLinkedListOutOfBoundsError : public DoublyLinkedListError {
    public:
        DoublyLinkedListOutOfBoundsError();
};

#endif //TESTDOUBLELINKEDLIST_DOUBLYLINKEDLISTOUTOFBOUNDSERROR_H
