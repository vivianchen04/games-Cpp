#ifndef LINKEDLIST_DOUBLELINKEDNODE_H
#define LINKEDLIST_DOUBLELINKEDNODE_H
#include <iostream>

//template<typename T>
//class DoublyLinkedNode {
//    public:
//        T value;
//       DoublyLinkedNode<T>* next;
//        DoublyLinkedNode<T>* prev;
//};

template<typename T>
class DoublyLinkedNode {
    public:
        DoublyLinkedNode();
        DoublyLinkedNode(const T& value);
        DoublyLinkedNode(const T& value, DoublyLinkedNode<T>* nextNode, DoublyLinkedNode<T>* prevNode);

        T& getValue();
        const T& getValue() const;
        DoublyLinkedNode<T>* getPrevPtr() const;
        DoublyLinkedNode<T>* getNextPtr() const;

        void setValue(const T& nodeValue);
        void setPrevPtr(DoublyLinkedNode<T>* prevNode);
        void setNextPtr(DoublyLinkedNode<T>* nextNode);

    private:
        T value;
        DoublyLinkedNode<T>* next;
        DoublyLinkedNode<T>* prev;
};

template<typename T>
DoublyLinkedNode<T>::DoublyLinkedNode() : next(nullptr), prev(nullptr) {

}

template<typename T>
DoublyLinkedNode<T>::DoublyLinkedNode(const T& value) : value(value), next(nullptr), prev(nullptr) {

}

template<typename T>
DoublyLinkedNode<T>::DoublyLinkedNode(const T& value, DoublyLinkedNode<T>* nextNode, DoublyLinkedNode<T>* prevNode) : value(value), next(nextNode), prev(prevNode) {

}

template<typename T>
T& DoublyLinkedNode<T>::getValue() {
    return value;
}

template<typename T>
const T& DoublyLinkedNode<T>::getValue() const {
    return value;
}

template<typename T>
DoublyLinkedNode<T>* DoublyLinkedNode<T>::getPrevPtr() const {
    return prev;
}

template<typename T>
DoublyLinkedNode<T>* DoublyLinkedNode<T>::getNextPtr() const {
    return next;
}

template<typename T>
void DoublyLinkedNode<T>::setValue(const T& nodeValue) {
    value = nodeValue;
}

template<typename T>
void DoublyLinkedNode<T>::setPrevPtr(DoublyLinkedNode<T>* prevNode) {
    prev = prevNode;
}

template<typename T>
void DoublyLinkedNode<T>::setNextPtr(DoublyLinkedNode<T>* nextNode) {
    next = nextNode;
}


#endif //LINKEDLIST_DOUBLELINKEDNODE_H
