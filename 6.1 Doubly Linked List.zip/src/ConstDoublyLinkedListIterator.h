#ifndef DLLPROJECT_CONSTDOUBLYLINKEDLISTITERATOR_H
#define DLLPROJECT_CONSTDOUBLYLINKEDLISTITERATOR_H

#include <iterator>
#include "DoublyLinkedNode.h"
#include "DoublyLinkedListOutOfBoundsError.h"

template<typename T>
class ConstDoublyLinkedListIterator {
public:
    //type tags
    using iterator_category = std::bidirectional_iterator_tag;
    using value_type = T;
    using reference = const value_type&;
    using pointer = const value_type*;
    using difference_type = ptrdiff_t;

    //create an iterator starting at the specified node
    explicit ConstDoublyLinkedListIterator(const DoublyLinkedNode<T>* start);

    //set the iterator to be at null
    ConstDoublyLinkedListIterator();

    //copy constructor
    ConstDoublyLinkedListIterator(const ConstDoublyLinkedListIterator<T>& orig);

    //are the two iterators equal?
    bool operator==(const ConstDoublyLinkedListIterator<T>& rhs) const;
    //are the two iterators different?
    bool operator!=(const ConstDoublyLinkedListIterator<T>& rhs) const;
    //is the iterator safe to dereference?
    explicit operator bool() const;

    //go to the next element
    ConstDoublyLinkedListIterator<T>& operator++(); //pre
    const ConstDoublyLinkedListIterator<T> operator++(int);//post

    //go to the prev element
    ConstDoublyLinkedListIterator<T>& operator--(); //pre
    const ConstDoublyLinkedListIterator<T> operator--(int); //post

    //get a reference to the value
    reference operator*() const;

    const DoublyLinkedNode<T>* getCurNode() const;

private:
    const DoublyLinkedNode<T>* curNode;
};

template<typename T>
ConstDoublyLinkedListIterator<T>::ConstDoublyLinkedListIterator(const DoublyLinkedNode<T>* start) : curNode(start) {

}

template<typename T>
ConstDoublyLinkedListIterator<T>::ConstDoublyLinkedListIterator() : curNode(nullptr) {

}

template<typename T>
ConstDoublyLinkedListIterator<T>::ConstDoublyLinkedListIterator(const ConstDoublyLinkedListIterator<T>& orig) : curNode(orig.curNode) {
//    DoublyLinkedNode<T>* origCurrentNodePtr = orig.curNode;
//
//    if (origCurrentNodePtr == nullptr) {
//        curNode = nullptr;
//    } else {
//        curNode = new DoublyLinkedNode<T> (); //A
//        curNode->setValue(origCurrentNodePtr->getValue());
//
//        DoublyLinkedNode<T>* currentNodePtr = curNode; //create A
//        currentNodePtr->setPrevPtr(nullptr); //A's prev is nullptr
//        origCurrentNodePtr = origCurrentNodePtr->getNextPtr(); //B
//
//        while (origCurrentNodePtr != nullptr) {
//            T nextValue = origCurrentNodePtr->value; //B value
//
//            DoublyLinkedNode<T>* newNodePtr = new DoublyLinkedNode<T> (); //create B
//            newNodePtr->setValue(nextValue);
//
//            currentNodePtr->setNextPtr(newNodePtr); //A's next is B
//            newNodePtr->setPrevPtr(currentNodePtr); //B's prev is A
//
//            currentNodePtr = currentNodePtr->getNextPtr(); //B
//            origCurrentNodePtr = currentNodePtr->getNextPtr(); //C
//        }
//
//        currentNodePtr->setNextPtr(nullptr);
//    }
}

template<typename T>
bool ConstDoublyLinkedListIterator<T>::operator==(const ConstDoublyLinkedListIterator<T>& rhs) const {
    return curNode == rhs.curNode;
}

template<typename T>
bool ConstDoublyLinkedListIterator<T>::operator!=(const ConstDoublyLinkedListIterator<T>& rhs) const {
    return !(*this == rhs);
}

template<typename T>
ConstDoublyLinkedListIterator<T>::operator bool() const {
    return curNode != nullptr;
}

template<typename T>
ConstDoublyLinkedListIterator<T>& ConstDoublyLinkedListIterator<T>::operator++() {
    curNode = curNode->getNextPtr();
    return *this;
}

template<typename T>
const ConstDoublyLinkedListIterator<T> ConstDoublyLinkedListIterator<T>::operator++(int) {
    ConstDoublyLinkedListIterator<T> curPos(*this);
    ++(*this);
    return curPos;
}

template<typename T>
ConstDoublyLinkedListIterator<T>& ConstDoublyLinkedListIterator<T>::operator--() {
    curNode = curNode->getPrevPtr();
    return *this;
}

template<typename T>
const ConstDoublyLinkedListIterator<T> ConstDoublyLinkedListIterator<T>::operator--(int) {
    ConstDoublyLinkedListIterator<T> curPos(*this);
    --(*this);
    return curPos;
}

template<typename T>
typename ConstDoublyLinkedListIterator<T>::reference ConstDoublyLinkedListIterator<T>::operator*() const {
    if (*this) {
        return curNode->getValue();
    } else {
        throw DoublyLinkedListOutOfBoundsError();
    }
}

template<typename T>
const DoublyLinkedNode<T>* ConstDoublyLinkedListIterator<T>::getCurNode() const {
    return curNode;
}


#endif //DLLPROJECT_CONSTDOUBLYLINKEDLISTITERATOR_H
