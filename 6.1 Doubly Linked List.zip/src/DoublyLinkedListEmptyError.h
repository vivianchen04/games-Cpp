#ifndef TESTDOUBLELINKEDLIST_DOUBLYLINKEDLISTEMPTYERROR_H
#define TESTDOUBLELINKEDLIST_DOUBLYLINKEDLISTEMPTYERROR_H

#include "DoublyLinkedListError.h"

class DoublyLinkedListEmptyError : public DoublyLinkedListError {
    public:
        DoublyLinkedListEmptyError();
};



#endif //TESTDOUBLELINKEDLIST_DOUBLYLINKEDLISTEMPTYERROR_H
