#include <sstream>
#include "DoublyLinkedListOutOfBoundsError.h"

DoublyLinkedListOutOfBoundsError::DoublyLinkedListOutOfBoundsError() {
    std::stringstream errorStream;
    errorStream << "Cannot dereference an iterator that is out of bounds." << std::endl;
    errorString = errorStream.str();
}
