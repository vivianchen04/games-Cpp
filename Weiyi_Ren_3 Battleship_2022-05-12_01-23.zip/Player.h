//
// Created by Lingxiao Ren on 5/10/22.
//

#ifndef BATTLESHIP_PLAYER_H
#define BATTLESHIP_PLAYER_H

#include "Board.h"
#include "FileData.h"
#include "InputValidation.h"
#include <utility>
#include <memory>

namespace BattleShip {

  bool Are_Two_Ints(std::string& prompt, int& num1, int& num2);
  std::pair<int, int> Get_Pair(std::string& prompt);

  class Player {
    public:
      // constructor
      Player(Board& placement_board, Board& fire_board, int number);

      // basic getter function
      std::string Get_Player_Name() const;
      const Board& Get_Player_Placement_Board() const;
      const Board& Get_Player_File_Board() const;

      // print functions
      void Print_Placement_Board() const;
      void Print_Fire_Board() const;

      // initialize functions
      void Place_Ships(const std::vector<std::pair<char, int>>& ship_vec);
      std::string Prompt_HV(char ship_name) const;
      std::string Prompt_Pair(char ship_name, int length) const;

      // fire functions
      std::string Prompt_Fire() const;
      std::pair<int, int> Fire() const;
      bool Does_Hit(std::pair<int, int> coordinate) const;
      void Hit_Target_Place(std::pair<int, int> coordinate);
      void Hit_Target_Fire(std::pair<int, int> coordinate);
      void Not_Hit_Place(std::pair<int, int> coordinate);
      void Not_Hit_Fire(std::pair<int, int> coordinate);
      char Hit_Name(std::pair<int, int> coordinate);
      bool Is_Destroyed(char hit_name);

    private:
      // basic player information
      std::string m_name;

      // two boards
      Board& m_placement_board;
      Board& m_fire_board;
  };

} // BattleShip

#endif //BATTLESHIP_PLAYER_H
