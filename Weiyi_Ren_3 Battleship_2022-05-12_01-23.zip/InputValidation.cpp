//
// Created by Lingxiao Ren on 5/10/22.
//

#include "InputValidation.h"

namespace BattleShip {

  char Get_Valid_Char(const std::string& prompt) {
    std::string line;
    while (true) {
      std::cout << prompt;
      std::getline(std::cin, line);
      std::stringstream line2parse(line);
      char choice;
      line2parse >> choice;
      if (line2parse) {
        std::string what_is_left;
        line2parse >> what_is_left;
        if (not line2parse) {
          if (choice == 'H' || choice == 'h' || choice == 'V' || choice == 'v') {
            return choice;
          }
        }
      }
    }
  }

  bool Get_Two_Ints(const std::string& prompt, int& num1, int& num2) {
    std::string line;
    while (true) {
      std::cout << prompt;
      std::getline(std::cin, line);
      std::stringstream line2parse(line);
      line2parse >> num1 >> num2;
      if (line2parse) {
        std::string what_is_left;
        line2parse >> what_is_left;
        if (not line2parse) {
          return true;
        }
      }
    }
  }

} // BattleShip
