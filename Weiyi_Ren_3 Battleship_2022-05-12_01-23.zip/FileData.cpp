//
// Created by Lingxiao Ren on 5/8/22.
//

#include <sstream>
#include "FileData.h"

bool BattleShip::cmp(const std::pair<char, int>& left_pair, const std::pair<char, int>& right_pair) {
  return left_pair.first < right_pair.first;
}

BattleShip::FileData::FileData(const std::string& file_name) {

  m_num_row = -1;
  m_num_col = -1;
  m_num_ship = -1;

  std::ifstream configFS;
  std::pair<char, int> ship_data;
  char ship_name;
  int ship_length;

  configFS.open(file_name);

  configFS >> m_num_row;
  configFS >> m_num_col;
  configFS >> m_num_ship;

  for (int i = 0; i < m_num_ship; ++i) {
    configFS >> ship_name;
    configFS >> ship_length;
    ship_data = std::make_pair(ship_name, ship_length);
    m_ship_vec.push_back(ship_data);
  }

  std::sort(m_ship_vec.begin(), m_ship_vec.end(), cmp);

  configFS.close();
}

int BattleShip::FileData::Get_Num_Row() const {
  return m_num_row;
}

int BattleShip::FileData::Get_Num_Col() const {
  return m_num_col;
}

const int& BattleShip::FileData::Get_Num_Ship() const {
  return m_num_ship;
}

const std::vector<std::pair<char, int>>& BattleShip::FileData::Get_Ship_Vec() const {
  return m_ship_vec;
}

void BattleShip::FileData::Print_Ship_Data() const {
  std::cout << m_num_row << std::endl;
  std::cout << m_num_col << std::endl;
  std::cout << m_num_ship << std::endl;
  for (auto itr = m_ship_vec.begin(); itr != m_ship_vec.end(); ++itr) {
    std::cout << itr->first << " " << itr->second << std::endl;
  }
}


