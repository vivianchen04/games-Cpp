//
// Created by Lingxiao Ren on 5/10/22.
//

#include "Player.h"

#include <sstream>

namespace BattleShip {

  bool Are_Two_Ints(std::string& prompt, int& num1, int& num2) {

    std::string line;
    std::cout << prompt;
    std::getline(std::cin, line);
    std::stringstream line2parse(line);
    line2parse >> num1 >> num2;
    if (line2parse) {
      std::string what_is_left;
      line2parse >> what_is_left;
      if (not line2parse) {
        return true;
      }
    }
    return false;
  }

  std::pair<int, int> Get_Pair(std::string& prompt) {

    int num1;
    int num2;
    std::pair<int, int> pair;

    Get_Two_Ints(prompt, num1, num2);
    pair = std::make_pair(num1, num2);

    return pair;
  }

  // constructor function
  Player::Player(Board& placement_board, Board& fire_board, int number)
          : m_placement_board(placement_board), m_fire_board(fire_board) {
    std::cout << "Player " << number << " please enter your name: ";
    std::getline(std::cin, m_name);
    /*std::cin >> m_name;
    std::cin.ignore();*/
  }

  std::string Player::Get_Player_Name() const {
    return m_name;
  }

  void Player::Place_Ships(const std::vector<std::pair<char, int>>& ship_vec) {

    m_placement_board.Print_Board();

    for (auto itr = ship_vec.begin(); itr != ship_vec.end(); ++itr) {

      //m_placement_board.Print_Board();

      char choice;
      char ship_name = itr->first;
      int length = itr->second;
      std::string prompt_HV = Prompt_HV(ship_name);
      std::string prompt_pair = Prompt_Pair(ship_name, length);

      while (true) {
        choice = Get_Valid_Char(prompt_HV);
        if (choice == 'H' || choice == 'h') {
          int num1, num2;
          if (!Are_Two_Ints(prompt_pair, num1, num2)) {
            continue;
          }
          std::pair<int, int> bow_pair = std::make_pair(num1, num2);
          std::pair<int, int> stern_pair = std::make_pair(bow_pair.first, bow_pair.second + length - 1);
          bool can_place_ship = m_placement_board.Is_Pair_Inside_Board(bow_pair) &&
                                m_placement_board.Is_Pair_Inside_Board(stern_pair) &&
                                m_placement_board.Can_Place_Ship(bow_pair, stern_pair);
          if (can_place_ship) {
            m_placement_board.Place_Ship(bow_pair, stern_pair, ship_name);
            break;
          }
        } else {
          int num1, num2;
          if (!Are_Two_Ints(prompt_pair, num1, num2)) {
            continue;
          }
          std::pair<int, int> bow_pair = std::make_pair(num1, num2);
          std::pair<int, int> stern_pair = std::make_pair(bow_pair.first + length - 1, bow_pair.second);
          bool can_place_ship = m_placement_board.Is_Pair_Inside_Board(bow_pair) &&
                                m_placement_board.Is_Pair_Inside_Board(stern_pair) &&
                                m_placement_board.Can_Place_Ship(bow_pair, stern_pair);
          if (can_place_ship) {
            m_placement_board.Place_Ship(bow_pair, stern_pair, ship_name);
            break;
          }
        }
      }
      m_placement_board.Print_Board();
    }
  }

  std::string Player::Prompt_HV(char ship_name) const {

    std::string prompt;
    std::ostringstream promptOSS;

    promptOSS.clear();
    promptOSS << m_name << ", do you want to place " << ship_name << " horizontally or vertically?\n";
    promptOSS << "Enter h for horizontal or v for vertical\n";
    promptOSS << "Your choice: ";

    prompt = promptOSS.str();

    return prompt;
  }

  std::string Player::Prompt_Pair(char ship_name, int length) const {

    std::string prompt;
    std::ostringstream promptOSS;

    promptOSS.clear();
    promptOSS << m_name << ", enter the row and column you want to place " << ship_name << ", which is " << length;
    promptOSS << " long, at with a space in between row and col: ";

    prompt = promptOSS.str();

    return prompt;
  }

  const Board& Player::Get_Player_Placement_Board() const {
    return m_placement_board;
  }

  const Board& Player::Get_Player_File_Board() const {
    return m_fire_board;
  }

  void Player::Print_Placement_Board() const {
    m_placement_board.Print_Board();
  }

  void Player::Print_Fire_Board() const {
    m_fire_board.Print_Board();
  }

  std::string Player::Prompt_Fire() const {

    std::string prompt;
    std::ostringstream promptOSS;

    promptOSS.clear();
    promptOSS << m_name << ", where would you like to fire?\n";
    promptOSS << "Enter your attack coordinate in the form row col: ";

    prompt = promptOSS.str();

    return prompt;
  }

  std::pair<int, int> Player::Fire() const {

    std::pair<int, int> fire_coord;
    std::string prompt = Prompt_Fire();

    while (true) {

      std::cout << m_name << "'s Firing Board" << std::endl;
      m_fire_board.Print_Board();
      std::cout << std::endl;
      std::cout << std::endl;
      std::cout << m_name << "'s Placement Board" << std::endl;
      m_placement_board.Print_Board();

      fire_coord = Get_Pair(prompt);
      if (m_fire_board.Is_Pair_Inside_Board(fire_coord) && m_fire_board.Can_Fire(fire_coord)) {
        break;
      }
    }
    return fire_coord;
  }

  bool Player::Does_Hit(std::pair<int, int> coordinate) const {
    return m_placement_board.Does_Hit(coordinate);
  }

  void Player::Hit_Target_Place(std::pair<int, int> coordinate) {
    m_placement_board.Hit(coordinate);
  }

  void Player::Hit_Target_Fire(std::pair<int, int> coordinate) {
    m_fire_board.Hit(coordinate);
  }

  void Player::Not_Hit_Place(std::pair<int, int> coordinate) {
    m_placement_board.Not_Hit(coordinate);
  }

  void Player::Not_Hit_Fire(std::pair<int, int> coordinate) {
    m_fire_board.Not_Hit(coordinate);
  }

  bool Player::Is_Destroyed(char hit_name) {
    return m_placement_board.Is_Destroyed(hit_name);
  }

  char Player::Hit_Name(std::pair<int, int> coordinate) {
    return m_placement_board.Hit_Name(coordinate);
  }

} // BattleShip