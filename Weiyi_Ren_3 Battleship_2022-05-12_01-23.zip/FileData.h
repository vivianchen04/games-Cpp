//
// Created by Lingxiao Ren on 5/8/22.
//

#ifndef BATTLESHIP_FILEDATA_H
#define BATTLESHIP_FILEDATA_H

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>
#include <memory>

namespace BattleShip {

  bool cmp(const std::pair<char, int>& left_pair, const std::pair<char, int>& right_pair);

  class FileData {
    public:
      // constructor
      explicit FileData(const std::string& file_name);

      // basic getter functions
      int Get_Num_Row() const;
      int Get_Num_Col() const;
      const int& Get_Num_Ship() const;
      const std::vector<std::pair<char, int>>& Get_Ship_Vec() const;

      // print function
      void Print_Ship_Data() const;

    private:
      // basic board information
      int m_num_row;
      int m_num_col;

      // basic ships information
      int m_num_ship;
      std::vector<std::pair<char, int>> m_ship_vec;
  };

} // BattleShip

#endif //BATTLESHIP_FILEDATA_H
