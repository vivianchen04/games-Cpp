//
// Created by Lingxiao Ren on 5/11/22.
//

#ifndef BATTLESHIP_PLAYGAME_H
#define BATTLESHIP_PLAYGAME_H

#include "Player.h"
#include <memory>

namespace BattleShip {

  bool Has_Finished(std::unique_ptr<BattleShip::Player>& player1_ptr, std::unique_ptr<BattleShip::Player>& player2_ptr,
                    const std::vector<std::pair<char, int>>& ship_vec);

  void Play_Game(std::unique_ptr<BattleShip::Player>& player1_ptr, std::unique_ptr<BattleShip::Player>& player2_ptr,
                 const BattleShip::FileData& config);

  bool Has_P1_Win(const Board& p2_placement_board, const std::vector<std::pair<char, int>>& ship_vec);

  bool Has_P2_Win(const Board& p1_placement_board, const std::vector<std::pair<char, int>>& ship_vec);

  void P1_Move(std::unique_ptr<BattleShip::Player>& p1_ptr, std::unique_ptr<BattleShip::Player>& p2_ptr);

  void P2_Move(std::unique_ptr<BattleShip::Player>& p2_ptr, std::unique_ptr<BattleShip::Player>& p1_ptr);

}

#endif //BATTLESHIP_PLAYGAME_H
