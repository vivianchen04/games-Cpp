//
// Created by Lingxiao Ren on 5/9/22.
//

#include "Board.h"

namespace BattleShip
{

  Board::Board(const FileData& config_info) {  // so FileData& is actually creating a instance of class?

    //initialize member variables
    m_num_row = config_info.Get_Num_Row();
    m_num_col = config_info.Get_Num_Col();

    //dynamically allocating memory
    m_board = new char* [m_num_row];  // check how to dynamically allocate memory in c++ later
    for (int i = 0; i < m_num_row; ++i) {
      m_board[i] = new char [m_num_col];
    }

    //fill in the default board
    for (int i = 0; i < m_num_row; ++i) {
      for (int j = 0; j < m_num_col; ++j) {
        m_board[i][j] = '*';
      }
    }
    //finish constructor
  }

  Board::~Board() {
    for (int i = 0; i < m_num_row; ++i) {  //why??
      delete[] m_board[i];
    }
    delete[] m_board;
  }

  int Board::Get_Num_Row() const {
    return m_num_row;
  }

  int Board::Get_Num_Col() const {
    return m_num_col;
  }

  char** Board::Get_Board() const {
    return m_board;
  }

  void Board::Print_Board() const {
    for (int i = 0; i < m_num_row + 1; ++i) {
      if (i == 0) {
        for (int j = 0; j < m_num_col + 1; ++j) {
          if (j == 0) {
            std::cout << ' ' << ' ';
          } else {
            std::cout << j - 1 << ' ';
          }
        }
        std::cout << std::endl;
      } else {
        std::cout << i - 1 << ' ';
        for (int k = 0; k < m_num_col; ++k) {
          std::cout << m_board[i-1][k] << ' ';
        }
        std::cout << std::endl;
      }
    }
  }

  bool Board::Is_Pair_Inside_Board(std::pair<int, int> coordinate) const {
    return (coordinate.first >= 0) && (coordinate.first <= m_num_row - 1) &&  // why num - 1
           (coordinate.second >= 0) && (coordinate.second <= m_num_col - 1);
  }

  bool Board::Can_Place_Ship(std::pair<int, int> bow_coordinate, std::pair<int, int> stern_coordinate) const {
    if ((Is_Pair_Inside_Board(bow_coordinate)) && (Is_Pair_Inside_Board(stern_coordinate))) {
      if (bow_coordinate.first == stern_coordinate.first) {
        for (int i = bow_coordinate.second; i <= stern_coordinate.second; ++i) {
          if (m_board[bow_coordinate.first][i] != '*') {
            return false;
          }
        }
        return true;
      } else {
        for (int i = bow_coordinate.first; i <= stern_coordinate.first; ++i) {
          if (m_board[i][bow_coordinate.second] != '*') {
            return false;
          }
        }
        return true;
      }
    } else {
      return false;
    }
  }

  void Board::Place_Ship(std::pair<int, int> bow_coord, std::pair<int, int> stern_coord, char ship) {
    if (bow_coord.first == stern_coord.first) {
      for (int i = bow_coord.second; i <= stern_coord.second; ++i) {
        m_board[bow_coord.first][i] = ship;
      }
    } else {
      for (int i = bow_coord.first; i <= stern_coord.first; ++i) {
        m_board[i][bow_coord.second] = ship;
      }
    }
  }

  bool Board::Is_Ship_Alive(char ship_name) const {
    for (int i = 0; i < m_num_row; ++i) {
      for (int j = 0; j < m_num_col; ++j) {
        if (m_board[i][j] == ship_name) {
          return true;
        }
      }
    }
    return false;
  }

  bool Board::Can_Fire(std::pair<int, int> coordinate) const {
    return m_board[coordinate.first][coordinate.second] == '*';
  }

  bool Board::Does_Hit(std::pair<int, int> coordinate) const {
    return m_board[coordinate.first][coordinate.second] != '*';
  }

  void Board::Hit(std::pair<int, int> coordinate) {
    m_board[coordinate.first][coordinate.second] = 'X';
  }

  void Board::Not_Hit(std::pair<int, int> coordinate) {
    m_board[coordinate.first][coordinate.second] = 'O';
  }

  char Board::Hit_Name(std::pair<int, int> coordinate) {
    return m_board[coordinate.first][coordinate.second];
  }

  bool Board::Is_Destroyed(char hit_name) const {
    for (int i = 0; i < m_num_row; ++i) {
      for (int j = 0; j < m_num_col; ++j) {
        if (m_board[i][j] == hit_name) {
          return false;
        }
      }
    }
    return true;
  }

} // BattleShip