//
// Created by Lingxiao Ren on 5/10/22.
//

#ifndef BATTLESHIP_INPUTVALIDATION_H
#define BATTLESHIP_INPUTVALIDATION_H

#include <iostream>
#include <string>
#include <sstream>
#include <memory>

namespace BattleShip {
  char Get_Valid_Char(const std::string& prompt);
  bool Get_Two_Ints(const std::string& prompt, int& num1, int& num2);
}

#endif //BATTLESHIP_INPUTVALIDATION_H
