//
// Created by mfbut on 4/24/2022.
//

#include <string>
#include <sstream>
#include "Game.h"

void parse_args(int argc, char** argv, int& seed, int& dice_per_player, int& max_face_value,
                bool& num_dice_can_reset_when_increasing_face){
    const std::string seed_flag("-s"), dice_flag("-d"), value_flag("-v"), reset_flag("-r");
    for (int i = 1; i < argc; ++i) {
        if(argv[i] == seed_flag){
            ++i;
            std::stringstream arg_parser(argv[i]);
            arg_parser >> seed;
        }else if(argv[i] == dice_flag){
            ++i;
            std::stringstream arg_parser(argv[i]);
            arg_parser >> dice_per_player;
        }else if(argv[i] == value_flag){
            ++i;
            std::stringstream arg_parser(argv[i]);
            arg_parser >> max_face_value;
        }else if(argv[i] == reset_flag){
            num_dice_can_reset_when_increasing_face = true;
        }

    }

}

int main(int argc, char** argv){
    int seed = time(nullptr);
    int dice_per_player = 3;
    int max_face_value = 6;
    bool num_dice_can_reset_when_increasing_face = false;


    parse_args(argc, argv, seed, dice_per_player, max_face_value, num_dice_can_reset_when_increasing_face);

    LiarsDice::Game the_game = LiarsDice::Game::buildGameFromInput(dice_per_player,max_face_value,
                                                                   num_dice_can_reset_when_increasing_face,
                                                                   seed);
    the_game.play();

    return 0;
}