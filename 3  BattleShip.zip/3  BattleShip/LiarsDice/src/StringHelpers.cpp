//
// Created by mfbut on 4/29/2022.
//
#include <cctype>
#include <algorithm>
#include "StringHelpers.h"

void LiarsDice::lowerInPlace(std::string& string) {
    for (auto& letter: string) {
        letter = tolower(letter);
    }
}

std::string LiarsDice::lower(std::string string) {
    lowerInPlace(string);
    return string;
}

bool LiarsDice::startsWith(const std::string& string, const std::string& prefix) {
    return prefix.size() <= string.size() and
           std::equal(prefix.cbegin(), prefix.cend(), string.cbegin());
}
