//
// Created by mfbut on 4/27/2022.
//

#include "Bet.h"

LiarsDice::Bet::Bet(int amount, int face, bool num_dice_can_reset_when_increasing_face) : amount(amount), face(face), num_dice_can_reset_when_increasing_face(num_dice_can_reset_when_increasing_face) {}

LiarsDice::Bet::Bet(int amount, int face) : Bet(amount, face, true){

}
LiarsDice::Bet::Bet() : Bet(0, 1, true) {

}

void LiarsDice::Bet::setFace(int value) {
  this->face = value;
}

void LiarsDice::Bet::setAmount(int amount) {
    this->amount = amount;
}



int LiarsDice::Bet::getAmount() const {
    return amount;
}

int LiarsDice::Bet::getFace() const {
    return face;
}

bool LiarsDice::Bet::canNumDiceResetWhenIncreasingFace() const {
    return num_dice_can_reset_when_increasing_face;
}

bool LiarsDice::Bet::isLessThan(const LiarsDice::Bet& other) const{
    if(face == other.face){
        return amount < other.amount;
    }
    else if(num_dice_can_reset_when_increasing_face){
        return face < other.face ;
    }else{
        return face < other.face and amount <= other.amount;
    }
}
bool LiarsDice::Bet::isGreaterThan(const LiarsDice::Bet& other) const{
    if(face == other.face){
        return amount > other.amount;
    }
    else if(num_dice_can_reset_when_increasing_face){
        return face > other.face ;
    }else{
        return face > other.face and amount >= other.amount;
    }
}

bool LiarsDice::Bet::isEqualTo(const Bet& other) const {
    return face == other.face and amount == other.amount;
}

LiarsDice::Bet::Bet(bool num_dice_can_reset_when_increasing_face): Bet(0,1,num_dice_can_reset_when_increasing_face) {

}

bool LiarsDice::Bet::couldBeValid() const {
    return amount > 0 and face > 0;
}


