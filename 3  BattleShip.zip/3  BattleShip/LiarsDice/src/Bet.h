//
// Created by mfbut on 4/27/2022.
//

#ifndef LIARSDICE_BET_H
#define LIARSDICE_BET_H

namespace LiarsDice {

    class Bet {
    public:
        Bet(int amount, int face, bool num_dice_can_reset_when_increasing_face);
        Bet(int amount, int face);
        Bet();
        Bet(const Bet& orig) = default;
        explicit Bet(bool num_dice_can_reset_when_increasing_face);
        virtual ~Bet() = default;

        void setFace(int value);
        void setAmount(int amount);
        int getAmount() const;
        int getFace() const;
        bool canNumDiceResetWhenIncreasingFace() const;

        bool isLessThan(const Bet& other) const;
        bool isGreaterThan(const Bet& other) const;
        bool isEqualTo(const Bet& other) const;
        bool couldBeValid() const;
    private:
        int amount, face;
        bool num_dice_can_reset_when_increasing_face;

    };
}


#endif //LIARSDICE_BET_H
