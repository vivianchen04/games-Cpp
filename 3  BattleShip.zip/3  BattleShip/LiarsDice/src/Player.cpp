//
// Created by mfbut on 4/25/2022.
//

#include <sstream>
#include <map>
#include "Player.h"
#include "Bet.h"
#include "Die.h"
#include "inputValidation.h"
#include "Move.h"

LiarsDice::Player
LiarsDice::Player::createPlayerFromInput(int player_number, const std::set<std::string>& other_player_names,
                                         const std::vector<Die>& dice,
                                         std::istream& in, std::ostream& out) {
    std::stringstream player_name_prompt;
    player_name_prompt << "Player " << player_number << " please enter your name: ";
    std::string player_name;
    do {
        player_name = getValidString(player_name_prompt.str(), in, out);
    } while (other_player_names.count(player_name) > 0);
    return {player_name, dice};
}

LiarsDice::Player::Player(const std::string& name, const std::vector<Die>& dice) : name(name), dice(dice) {}

LiarsDice::Player::Player(const std::string& name, int num_dice, const Die& die) : name(name), dice(num_dice, die) {

}

void LiarsDice::Player::roll_dice() {
    for (auto& die: dice) {
        die.roll();
    }
}

LiarsDice::Move LiarsDice::Player::get_bet(const LiarsDice::Bet& cur_bet, std::istream& in, std::ostream& out) {
    std::string user_input;
    do {
        out << getName() << ", you rolled ";
        display_roll(out);
        out << std::endl;
        out << getName() << ", please enter a bet that is greater than " << cur_bet.getAmount() << ' ' << cur_bet.getFace() << "'s: ";

        std::getline(in, user_input); //read input
    }while(not Move::representsRaise(user_input,cur_bet));
    return Move::createRaiseMoveFromUserInput(*this, user_input, cur_bet);
}

int LiarsDice::Player::getNumberOfDiceFaceRolled(int face_value) const {
    int num_face_rolled = 0;
    for (const auto& die: dice) {
        if (die.isFaceEqualTo(face_value)) {
            num_face_rolled++;
        }
    }
    return num_face_rolled;
}

void LiarsDice::Player::loseADie() {
    dice.pop_back();
}

int LiarsDice::Player::getNumDice() const {
    return dice.size();
}

LiarsDice::Move
LiarsDice::Player::get_move(const LiarsDice::Bet& previous_bet, Player& previous_player, std::istream& in,
                            std::ostream& out) {

    out << getName() << ", you rolled ";  display_roll(out); out << std::endl;

    std::stringstream prompt;
    prompt << getName() << " please enter your move or h for help: ";
    out << prompt.str(); //prompt for input
    std::string user_input;
    std::getline(in, user_input); //read input

    if (Move::representsHelp(user_input)) {
        return Move::createHelpMoveFromUserInput(*this, user_input);
    } else if (Move::representsRaise(user_input, previous_bet)) {
        return Move::createRaiseMoveFromUserInput(*this, user_input, previous_bet);
    } else if (Move::representsSpotOnCall(user_input)) {
        return Move::createSpotOnCallMoveFromUserInput(*this, user_input);
    } else if (Move::representsCallLiar(user_input)) {
        return Move::createCallLiarMoveFromUserInput(*this, user_input, previous_player);
    } else {
        return Move::createInvalidMove(*this);
    }

}

bool LiarsDice::Player::hasDice(const LiarsDice::Player& player) {
    return not player.dice.empty();
}

const std::string& LiarsDice::Player::getName() const {
    return name;
}

LiarsDice::Player::Player(const std::string& name, int num_dice, int max_die_value) : name(name), dice(num_dice, Die(max_die_value)){

}

void LiarsDice::Player::display_roll(std::ostream& out) const{
    std::map<int, int> dice_counts = getDiceCounts();
    for(const auto& value_frequency: dice_counts){
        const auto& value = value_frequency.first;
        const auto& frequency = value_frequency.second;
        out << frequency << ' ' << value << "'s, ";
    }
}

std::map<int, int> LiarsDice::Player::getDiceCounts() const{
    std::map<int, int> dice_counts;
    for(const auto& die: dice){
        if(dice_counts.count(die.getValue()) == 0){
            dice_counts.insert({die.getValue(), 1});
        }else{
            dice_counts.at(die.getValue()) += 1;
        }
    }
    return dice_counts;
}





