//
// Created by mfbut on 4/27/2022.
//

#ifndef LIARSDICE_MOVE_H
#define LIARSDICE_MOVE_H

#include <string>
#include <istream>
#include "Bet.h"


namespace LiarsDice {
    class Player;

    enum class MoveType {
        HELP, INVALID, RAISE, LIAR, SPOT_ON
    };

    //static_cast<MoveType>(3);
    class Move {
    public:
        static bool representsHelp(const std::string& user_input);
        static bool representsRaise(const std::string& user_input, const Bet& previous_bet);
        static bool representsSpotOnCall(const std::string& user_input);
        static bool representsCallLiar(const std::string& user_input);


        static LiarsDice::Move createHelpMoveFromUserInput(Player& maker, const std::string&);
        static Move createRaiseMoveFromUserInput(Player& maker, const std::string& user_input, const Bet& previous_bet);
        static LiarsDice::Move
        createCallLiarMoveFromUserInput(Player& maker, const std::string&, Player& previous_player);
        static LiarsDice::Move createSpotOnCallMoveFromUserInput(Player& maker, const std::string&);
        static LiarsDice::Move createInvalidMove(Player& maker);

        Move(MoveType moveType, Player* maker, Player* accused, const Bet& betMade);
        Move(MoveType moveType, Player& maker);
        Move();

        void carryOut(Bet& cur_bet);
        bool doesEndTurn() const;
        bool isRoundOver() const;
        bool calledSpotOn() const;
        bool calledLiar() const;

        const Player& getMaker() const;
        Player& getMaker();

        Player& getAccused();
        const Player& getAccused() const;
    private:
        MoveType move_type;
        Player* maker;
        Player* accused;

        Bet bet_made;

    };
}

//const return_type fun(const arg) const;


#endif //LIARSDICE_MOVE_H
