//
// Created by mfbut on 4/25/2022.
//

#include <iostream>
#include <algorithm>
#include <string>
#include <iterator>
#include <utility>
#include <ctime>
#include <set>
#include <sstream>
#include "inputValidation.h"
#include "Die.h"
#include "Game.h"
#include "Player.h"
#include "Bet.h"
#include "Move.h"

LiarsDice::Game LiarsDice::Game::buildGameFromInput(int dice_per_player, int max_face_value,
                                                    bool num_dice_can_reset_when_increasing_face,
                                                    int seed,
                                                    std::istream& in, std::ostream& out) {
    const std::vector<Die> dice(dice_per_player, {max_face_value});
    std::set<std::string> player_names{""};
    std::vector<Player> players;
    int num_players = getValidInt("Enter the number of players in the game: ", in, out);
    for (int i = 0; i < num_players; ++i) {
        Player cur_player = Player::createPlayerFromInput(i + 1, player_names, dice, in, out);
        player_names.insert(cur_player.getName());
        players.push_back(std::move(cur_player));
    }
    return {players, num_dice_can_reset_when_increasing_face, seed};
}

LiarsDice::Game::Game(std::vector<Player> players, bool num_dice_can_reset_when_increasing_face, int seed) :
        active_players(std::move(players)), benched_players(),
        num_dice_can_reset_when_increasing_face(num_dice_can_reset_when_increasing_face) {
    Die::seedRandomNumberGenerator(seed);
}

LiarsDice::Game::Game(std::vector<Player> players, bool num_dice_can_reset_when_increasing_face) : Game(players,
                                                                                                        num_dice_can_reset_when_increasing_face,
                                                                                                        time(nullptr)) {

}


void LiarsDice::Game::play(std::istream& in, std::ostream& out) {
    while (not isGameOver()) {
        playARound(in, out);
    }
    declareResults(out);
}

bool LiarsDice::Game::isGameOver() const {
    /** The game is over when there is only 1 player with 1 or more dice
     * @returns: whether the game is over or not
     */
    return active_players.size() == 1;
}

void LiarsDice::Game::declareResults(std::ostream& out) const {
    out << active_players.front().getName() << " won the game!" << std::endl;
}

void LiarsDice::Game::playARound(std::istream& in, std::ostream& out) {
    haveAllPlayersRollTheirDice();
    Bet cur_bet(num_dice_can_reset_when_increasing_face);

    int cur_player_turn = 0;
    displayGameState(out);
    Move initial_bet = active_players.at(0).get_bet(cur_bet, in, out);
    initial_bet.carryOut(cur_bet);
    changeTurnToNextPlayer(cur_player_turn);

    Move move;

    do {
        do {
            displayGameState(out);
            move = active_players.at(cur_player_turn).get_move(cur_bet, getActivePlayerBefore(cur_player_turn), in, out);
            move.carryOut(cur_bet);
        } while (not move.doesEndTurn());
        changeTurnToNextPlayer(cur_player_turn);
    } while (not move.isRoundOver());

    updateDiceCounts(cur_bet, move);
    benchPlayersWithNoDiceLeft();

}

void LiarsDice::Game::haveAllPlayersRollTheirDice() {
    for (auto& player: active_players) {
        player.roll_dice();
    }

}

void LiarsDice::Game::changeTurnToNextPlayer(int& turn) {
    turn = (turn + 1) % active_players.size();
}

void LiarsDice::Game::updateDiceCounts(const Bet& bet, Move& move) {
    int actual_die_count = getNumberOfDiceFaceRolled(bet.getFace());

    if (move.calledSpotOn()) {
        if (actual_die_count == bet.getAmount()) {
            makeEveryoneButChallengerLoseDie(move.getMaker());
        } else {
            move.getMaker().loseADie(); //won't work because of const on move
        }
    } else if (move.calledLiar()) {
        if (actual_die_count < bet.getAmount()) {
            move.getAccused().loseADie();
        } else {
            move.getMaker().loseADie();
        }

    } else {
        //something bad happened
    }

}

int LiarsDice::Game::getNumberOfDiceFaceRolled(int die_face) const {
    int num_face_rolled = 0;
    for (const auto& player: active_players) {
        num_face_rolled += player.getNumberOfDiceFaceRolled(die_face);
    }
    return num_face_rolled;
}

void LiarsDice::Game::makeEveryoneButChallengerLoseDie(const Player& challenger) {
    for (auto& player: active_players) {
        if (&player != &challenger) {
            player.loseADie();
        }
    }
}

void LiarsDice::Game::benchPlayersWithNoDiceLeft() {
    // place all the players with no dice left after those that still have dice
    auto toRemove = std::stable_partition(active_players.begin(), active_players.end(), Player::hasDice);
    auto move_start = std::make_move_iterator(toRemove), move_end = std::make_move_iterator(active_players.end());
    // move the players that have no dice to the bench
    benched_players.insert(benched_players.end(), move_start, move_end);
    // remove the players we benched from the active list
    active_players.erase(toRemove, active_players.end());
}

LiarsDice::Player& LiarsDice::Game::getActivePlayerBefore(int position) {
    if (position == 0) {
        return active_players.back();
    } else {
        return active_players.at(position - 1);
    }
}

const LiarsDice::Player& LiarsDice::Game::getActivePlayerBefore(int position) const {
    if (position == 0) {
        return active_players.back();
    } else {
        return active_players.at(position - 1);
    }
}

void LiarsDice::Game::displayGameState(std::ostream& out) const{
    for (const auto& player: active_players) {
        out << player.getName() << " rolled: ";
        player.display_roll(out);
        out << std::endl;
    }
    out << std::endl;
}





