//
// Created by mfbut on 4/29/2022.
//

#ifndef LIARSDICE_STRINGHELPERS_H
#define LIARSDICE_STRINGHELPERS_H
#include <string>
namespace LiarsDice {
    void lowerInPlace(std::string& string);

    std::string lower(std::string string);

    bool startsWith(const std::string& string, const std::string& prefix);
}
#endif //LIARSDICE_STRINGHELPERS_H
