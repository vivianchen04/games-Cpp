//
// Created by mfbut on 4/27/2022.
//
#include <string>
#include <set>
#include <sstream>
#include "Move.h"
#include "inputValidation.h"
#include "StringHelpers.h"
#include "Player.h"

bool LiarsDice::Move::representsHelp(const std::string& user_input) {
    std::stringstream input_parser(user_input);
    std::string command_word;
    input_parser >> command_word;
    return input_parser and
           startsWith("help", lower(command_word))
           and is_stream_empty(input_parser);
}

bool LiarsDice::Move::representsRaise(const std::string& user_input, const Bet& previous_bet) {
    std::stringstream input_parser(user_input);
    std::string command_word;
    int num_dice = -1, face = -1;
    input_parser >> command_word >> num_dice >> face;

    if(input_parser and
           startsWith("raise", lower(command_word))
           and is_stream_empty(input_parser)){
        Bet cur_bet(num_dice, face, previous_bet.canNumDiceResetWhenIncreasingFace());
        return cur_bet.couldBeValid() and cur_bet.isGreaterThan(previous_bet);
    }else{
        return false;
    }
}

//std::vector<std::unique_ptr<Player>> players;
//players.push_back(std::make_unique<Player>(constructor_arguments for aplayer));

bool LiarsDice::Move::representsSpotOnCall(const std::string& user_input) {
    std::stringstream input_parser(user_input);
    std::string command_word;
    input_parser >> command_word;
    return input_parser and
           startsWith("spoton", lower(command_word))
           and is_stream_empty(input_parser);
}

bool LiarsDice::Move::representsCallLiar(const std::string& user_input) {
    std::stringstream input_parser(user_input);
    std::string command_word;
    input_parser >> command_word;
    return input_parser and
           startsWith("liar", lower(command_word))
           and is_stream_empty(input_parser);
}


LiarsDice::Move LiarsDice::Move::createHelpMoveFromUserInput(Player& maker, const std::string&) {
    return {MoveType::HELP, maker};

}

LiarsDice::Move
LiarsDice::Move::createRaiseMoveFromUserInput(Player& maker, const std::string& user_input, const Bet& previous_bet) {
    std::stringstream input_parser(user_input);
    std::string command_word;
    int amount, face;

    input_parser >> command_word >> amount >> face;
    Bet bet(amount, face, previous_bet.canNumDiceResetWhenIncreasingFace()); //guareenteed bet is at least the previous bet because we checked it
    //in representsRaise
    return Move(MoveType::RAISE, &maker, nullptr, bet);

}

LiarsDice::Move
LiarsDice::Move::createCallLiarMoveFromUserInput(Player& maker, const std::string&, Player& previous_player) {
    return Move(MoveType::LIAR, &maker, &previous_player, Bet());
}

LiarsDice::Move LiarsDice::Move::createSpotOnCallMoveFromUserInput(Player& maker, const std::string&) {
    return Move(MoveType::SPOT_ON, maker);
}

void LiarsDice::Move::carryOut(Bet& cur_bet) {
    if (move_type == MoveType::INVALID) {
        std::cout << "What you entered is invalid" << std::endl;

    } else if (move_type == MoveType::HELP) {
        std::cout << "These are the inputs you can enter" << std::endl;

    } else if (move_type == MoveType::LIAR) {

    } else if (move_type == MoveType::RAISE) {
        cur_bet = bet_made;
    } else if (move_type == MoveType::SPOT_ON) {

    }

}

bool LiarsDice::Move::doesEndTurn() const {
    const std::set<MoveType> turn_enders{MoveType::LIAR, MoveType::RAISE, MoveType::SPOT_ON};
    return turn_enders.count(move_type) == 1;
}

bool LiarsDice::Move::isRoundOver() const {
    const std::set<MoveType> round_enders{MoveType::LIAR, MoveType::SPOT_ON};
    return round_enders.count(move_type) == 1;
}

bool LiarsDice::Move::calledSpotOn() const {
    return move_type == MoveType::SPOT_ON;
}

bool LiarsDice::Move::calledLiar() const {
    return move_type == MoveType::LIAR;
}


const LiarsDice::Player& LiarsDice::Move::getMaker() const {
    return *maker;
}

LiarsDice::Player& LiarsDice::Move::getMaker() {
    return *maker;
}

LiarsDice::Player& LiarsDice::Move::getAccused() {
    if (accused == nullptr) {
        std::cout << "Trying to access the accused when it does it exist" << std::endl;
    }
    return *accused;
}

const LiarsDice::Player& LiarsDice::Move::getAccused() const {
    if (accused == nullptr) {
        std::cout << "Trying to access the accused when it does it exist" << std::endl;
    }
    return *accused;
}

LiarsDice::Move::Move(LiarsDice::MoveType moveType, LiarsDice::Player* maker, LiarsDice::Player* accused,
                      const LiarsDice::Bet& betMade) : move_type(moveType), maker(maker), accused(accused),
                                                       bet_made(betMade) {}

LiarsDice::Move::Move(MoveType moveType, Player& maker) : Move(moveType, &maker, nullptr, Bet()) {}

LiarsDice::Move::Move() : Move(MoveType::INVALID, nullptr, nullptr, Bet()){

}

LiarsDice::Move LiarsDice::Move::createInvalidMove(Player& maker) {
    return Move(MoveType::INVALID, maker);
}



