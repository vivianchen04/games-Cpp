//
// Created by mfbut on 4/27/2022.
//

#include <ctime>
#include <random>
#include "Die.h"

std::minstd_rand LiarsDice::Die::rng(time(nullptr));

void LiarsDice::Die::seedRandomNumberGenerator(int seed) {
    rng.seed(seed);
}


int LiarsDice::Die::roll() {
    value = face_roller(rng);
    return value;
}

LiarsDice::Die::Die(int num_faces) : face_roller(1, num_faces), value(1){

}

LiarsDice::Die::Die() : Die(6){

}

int LiarsDice::Die::getValue() const {
    return value;
}

int LiarsDice::Die::getMaxRollableValue() const{
    return face_roller.max();
}

bool LiarsDice::Die::isFaceEqualTo(int face) const {
    return value == face;
}

