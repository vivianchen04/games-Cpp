//
// Created by mfbut on 4/25/2022.
//

#ifndef LIARSDICE_PLAYER_H
#define LIARSDICE_PLAYER_H

#include <vector>
#include <set>
#include <iostream>
#include <string>
#include <map>
#include "Die.h"


namespace LiarsDice {
    class Move;
    class Bet;

    class Player {

    public:
        static bool hasDice(const Player& player);
        static Player createPlayerFromInput(int player_number, const std::set<std::string>& other_player_names,
                                            const std::vector<Die>& dice,
                                            std::istream& in = std::cin, std::ostream& out = std::cout);

        Player() = delete;
        Player(const std::string& name, const std::vector<Die>& dice);
        Player(const std::string& name, int num_dice, const Die& die);
        Player(const std::string& name, int num_dice, int max_die_value);

        const std::string& getName() const;


        void roll_dice();

        LiarsDice::Move get_bet(const LiarsDice::Bet& cur_bet, std::istream& in = std::cin, std::ostream& out = std::cout);

        int getNumberOfDiceFaceRolled(int face_value) const;

        void loseADie();
        int getNumDice() const;

        LiarsDice::Move get_move(const LiarsDice::Bet& previous_bet, Player& previous_player, std::istream& in,
                                 std::ostream& out);
        void display_roll(std::ostream& out) const;
        std::map<int, int> getDiceCounts() const;



    private:
        std::string name;
        std::vector<Die> dice;

    };
}


#endif //LIARSDICE_PLAYER_H
