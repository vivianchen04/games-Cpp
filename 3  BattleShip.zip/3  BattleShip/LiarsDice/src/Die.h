//
// Created by mfbut on 4/27/2022.
//

#ifndef LIARSDICE_DIE_H
#define LIARSDICE_DIE_H
#include <random>
namespace LiarsDice {
    class Die {
    public:
        static void seedRandomNumberGenerator(int seed);
        Die();
        Die(int num_faces);
        virtual ~Die() = default;
        int roll();

        int getValue() const;
        int getMaxRollableValue() const;

        bool isFaceEqualTo(int face) const;
    private:
        static std::minstd_rand rng;
        std::uniform_int_distribution<int> face_roller;
        int value;
    };
}


#endif //LIARSDICE_DIE_H
//Die d(6);