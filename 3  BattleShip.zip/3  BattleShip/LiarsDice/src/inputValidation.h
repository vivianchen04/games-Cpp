//
// Created by mfbut on 4/27/2022.
//

#ifndef LIARSDICE_INPUTVALIDATION_H
#define LIARSDICE_INPUTVALIDATION_H

#include <string>
#include <iostream>
void get_two_ints(const std::string& prompt, int& num1, int& num2, std::istream& in = std::cin, std::ostream& out = std::cout);
int getValidInt(const std::string& prompt, std::istream& in = std::cin, std::ostream& out = std::cout);
std::string getValidString(const std::string& prompt, std::istream& in = std::cin, std::ostream& out = std::cout);

bool is_stream_empty(std::istream& in);

#endif //LIARSDICE_INPUTVALIDATION_H
