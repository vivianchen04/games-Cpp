//
// Created by mfbut on 4/25/2022.
//

#ifndef LIARSDICE_GAME_H
#define LIARSDICE_GAME_H

#include <iostream>
#include <vector>
#include "Player.h"

namespace LiarsDice {
    class Game {
    public:
        static LiarsDice::Game buildGameFromInput(int dice_per_player, int max_face_value,
                                                  bool num_dice_can_reset_when_increasing_face,
                                                  int seed,
                                                  std::istream&  =std::cin, std::ostream& out = std::cout);
        Game(std::vector<Player> players, bool num_dice_can_reset_when_increasing_face, int seed);
        Game(std::vector<Player> players, bool num_dice_can_reset_when_increasing_face);
        void play(std::istream& in = std::cin, std::ostream& out = std::cout);

    private:

        bool isGameOver() const;

        void declareResults(std::ostream& out) const;

        void playARound(std::istream& in, std::ostream& out);

        void haveAllPlayersRollTheirDice();

        void changeTurnToNextPlayer(int& turn);

        void updateDiceCounts(const Bet& bet, Move& move);

        int getNumberOfDiceFaceRolled(int die_face) const;

        void makeEveryoneButChallengerLoseDie(const Player& challenger);
        void benchPlayersWithNoDiceLeft();

        Player& getActivePlayerBefore(int position);
        const Player& getActivePlayerBefore(int position) const;
        void displayGameState(std::ostream& out) const;


        std::vector<Player> active_players;
        std::vector<Player> benched_players;
        bool num_dice_can_reset_when_increasing_face;


    };
}


#endif //LIARSDICE_GAME_H
