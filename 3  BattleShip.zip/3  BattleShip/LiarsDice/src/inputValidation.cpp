#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include<algorithm>
#include <fstream>
#include "inputValidation.h"


int word_count(std::ifstream& my_file) {
    int count = 0;
    std::string word;
    while (my_file >> word) {
        count++;
    }
    return count;
}


int getValidInt(const std::string& prompt, std::istream& in, std::ostream& out) {
    std::string line;
    while (true) {
        out << prompt; //print the prompt
        std::getline(in, line); //grabs the entire line
        std::stringstream line2parse(line);
        int num;
        line2parse >> num;
        if (line2parse) { //if I was able to read the number
            std::string what_is_left;
            line2parse >> what_is_left;
            if (not line2parse) { //if there is nothing left we will fail to read it
                return num;
            }
        }
    }
}


std::string getValidString(const std::string& prompt, std::istream& in, std::ostream& out) {
    std::string line;
    while (true) {
        out << prompt;
        std::getline(in, line); //grabs the entire line
        std::stringstream line2parse(line);
        std::string word;
        line2parse >> word;
        if (line2parse) { //if I was able to read the number
            std::string what_is_left;
            line2parse >> what_is_left;
            if (not line2parse) { //if there is nothing left we will fail to read it
                return word;
            }
        }
    }
}

void get_two_ints(const std::string& prompt, int& num1, int& num2, std::istream& in, std::ostream& out) {
    std::string line;
    while (true) {
        out << prompt;
        std::getline(in, line); //grabs the entire line
        std::stringstream line2parse(line);
        line2parse >> num1 >> num2;
        if (line2parse and is_stream_empty(line2parse)) { //if I was able to read the number
            return;
        }
    }

}

bool is_stream_empty(std::istream& in) {
    std::string leftovers;
    in >> leftovers;
    return not in; //failing to read means that the stream is empty
}

bool vector_contains(const std::vector<int>& values, const int& value) {
    return std::find(values.begin(), values.end(), value) != values.end();
}

int get_one_of_these_numbers(const std::string& prompt, const std::vector<int>& good_nums) {
    int num;
    do {
        num = getValidInt(prompt);
    } while (not vector_contains(good_nums, num));
    return num;
}
