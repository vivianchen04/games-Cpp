#include <iostream>
#include "FileData.h"
#include "Game.h"


int main(int argc, char** argv) {
  std::string file_name(argv[1]);
  BattleShip::FileData configure(file_name);
  //configure.Print_Ship_Data();
  BattleShip::Game(configure);

  return 0;
}
