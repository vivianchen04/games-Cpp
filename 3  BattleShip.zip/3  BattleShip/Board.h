//
// Created by Lingxiao Ren on 5/9/22.
//

#ifndef BATTLESHIP_BOARD_H
#define BATTLESHIP_BOARD_H

#include "FileData.h"
#include <memory>

namespace BattleShip {

  class Board {
    public:
      // constructor and destructor
      explicit Board(const FileData& config_info);
      ~Board();

      // basic getter functions
      int Get_Num_Row() const;
      int Get_Num_Col() const;
      char** Get_Board() const;

      // print function
      void Print_Board() const;

      // placing ships functions
      bool Is_Pair_Inside_Board(std::pair<int, int> coordinate) const;
      bool Can_Place_Ship(std::pair<int, int> bow_coordinate, std::pair<int, int> stern_coordinate) const;
      void Place_Ship(std::pair<int, int> bow_coord, std::pair<int, int> stern_coord, char ship);

      // firing functions
      bool Is_Ship_Alive(char ship_name) const;
      bool Can_Fire(std::pair<int, int> coordinate) const;
      bool Does_Hit(std::pair<int, int> coordinate) const;
      void Hit(std::pair<int, int> coordinate);
      void Not_Hit(std::pair<int, int> coordinate);
      char Hit_Name(std::pair<int, int> coordinate);
      bool Is_Destroyed(char hit_name) const;

    private:
      // basic board parameter
      int m_num_row;
      int m_num_col;

      // board pointer
      char** m_board;
  };

} // BattleShip

#endif //BATTLESHIP_BOARD_H
