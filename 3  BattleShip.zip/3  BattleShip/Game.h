//
// Created by Lingxiao Ren on 5/9/22.
//

#ifndef BATTLESHIP_GAME_H
#define BATTLESHIP_GAME_H

#include "FileData.h"
#include "Board.h"
#include "Player.h"
#include "PlayGame.h"
#include <memory>

namespace BattleShip {

  void Game(const FileData& config);
  void Initialize_Player1(std::unique_ptr<BattleShip::Player>& player1_ptr, const BattleShip::FileData& config);
  void Initialize_Player2(std::unique_ptr<BattleShip::Player>& player2_ptr, const BattleShip::FileData& config);

} // BattleShip


#endif //BATTLESHIP_GAME_H
