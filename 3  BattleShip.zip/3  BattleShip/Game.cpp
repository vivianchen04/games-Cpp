//
// Created by Lingxiao Ren on 5/9/22.
//

#include "Game.h"

void BattleShip::Initialize_Player1(std::unique_ptr<BattleShip::Player>& player1_ptr, const BattleShip::FileData& config) {
  const std::vector<std::pair<char, int>>& ship_vec = config.Get_Ship_Vec();
  player1_ptr->Place_Ships(ship_vec);
}

void BattleShip::Initialize_Player2(std::unique_ptr<BattleShip::Player>& player2_ptr, const BattleShip::FileData& config) {
  const std::vector<std::pair<char, int>>& ship_vec = config.Get_Ship_Vec();
  player2_ptr->Place_Ships(ship_vec);
}

void BattleShip::Game(const FileData& config) {

  BattleShip::Board player1_placement_board(config);
  BattleShip::Board player1_fire_board(config);
  auto player1_ptr = std::make_unique<Player>(player1_placement_board, player1_fire_board, 1);
  Initialize_Player1(player1_ptr, config);

  BattleShip::Board player2_placement_board(config);
  BattleShip::Board player2_fire_board(config);
  auto player2_ptr = std::make_unique<Player>(player2_placement_board, player2_fire_board, 2);
  Initialize_Player2(player2_ptr, config);

  Play_Game(player1_ptr, player2_ptr, config);

  player1_ptr.reset();
  player2_ptr.reset();

}




